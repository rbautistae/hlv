# Databricks notebook source
# MAGIC %md
# MAGIC # Parse BBG gethistory file

# COMMAND ----------

# MAGIC %md
# MAGIC ## simple parser

# COMMAND ----------

from parse import history_parser as hp

# COMMAND ----------

hp.test()

# COMMAND ----------

SRC_PATH = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/bbg/PriceIX_P_2024091720240917-090134.out"
DST_PATH = SRC_PATH.replace("out", "csv")
DST_PATH

# COMMAND ----------

# hp.get_csv_easy(SRC_PATH, DST_PATH)

# COMMAND ----------

# MAGIC %md
# MAGIC ## with pattern State

# COMMAND ----------

# from parse.gethistory_state import InitState, HeaderState, FieldState, DataState, EndState
from parse.gethistory_context import GetHistory

getHist = GetHistory(SRC_PATH, DST_PATH)
getHist.get_csv()


# COMMAND ----------

