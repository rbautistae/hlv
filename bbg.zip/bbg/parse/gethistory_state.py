from abc import ABC, abstractmethod

# Custom exception class to handle specific errors in the 'gethistory' data file
class GetHistFileException(Exception):
    """Custom exception for errors in the 'gethistory' data file."""
    pass

# Abstract base class for all states in the 'gethistory' file processing state machine.
class GetHistoryState(ABC):
    
    @abstractmethod
    def next_state(self, gethistory):  
        """
        Abstract method for transitioning to the next state.
        
        Parameters:
            gethistory (GetHistory): The context class that controls state transitions.
        """
        pass

    @abstractmethod
    def doJob(self, gethistory, line):  
        """
        Abstract method to process a line of input for the current state.
        
        Parameters:
            gethistory (GetHistory): The context class that controls state transitions.
            line (str): The current line from the input file to process.
        """
        pass

# Initial state: no processing occurs in this state. Moves to HeaderState.
class InitState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        Transitions from the InitState to the HeaderState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("changing to header state")
        gethistory.state = HeaderState()

    def doJob(self, gethistory, line):  
        """
        No operation in the InitState. This state acts as a starting point.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file to process (not used in this state).
        """
        pass

# HeaderState: Represents the state where header data is processed. Transitions to FieldState.
class HeaderState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        Transitions from the HeaderState to the FieldState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("changing to field state")
        gethistory.state = FieldState()

    def doJob(self, gethistory, line):  
        """
        No specific processing in HeaderState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file to process.
        Raises:
            GetHistFileException: If PROGRAMNAME is not 'gethistory' in the input file.
        """
        if line.startswith('PROGRAMNAME='):
            program_name = line.split('=', 1)[1].strip()
            if program_name != 'gethistory':
                raise GetHistFileException("PROGRAMNAME must be 'gethistory'.")

        

# FieldState: Handles the processing of the field block in the file. Transitions to TimeStartedState.
class FieldState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        Transitions from the FieldState to the TimeStartedState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("changing to time starter state")
        gethistory.state = TimeStartedState()

    def doJob(self, gethistory, line):
        """
        Processes a field line by appending it to the fields_block.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file representing a field.
        """
        gethistory.fields_block.append(line)

# TimeStartedState: Represents the state when the "time started" data is processed. Transitions to DataState.
class TimeStartedState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        Transitions from TimeStartedState to the DataState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("changing to data state")
        gethistory.state = DataState()

    def doJob(self, gethistory, line):  
        """
        No specific processing in TimeStartedState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file to process (not used in this state).
        """ 
        pass

# DataState: Responsible for processing the data block from the file. Transitions to TimeFinishedState.
class DataState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        Transitions from the DataState to the TimeFinishedState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("changing to time finished state")
        gethistory.state = TimeFinishedState()

    def doJob(self, gethistory, line):  
        """
        Processes each data row by splitting the line on '|', trimming each field, 
        and removing the last element from the row before appending it to the data_block.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file representing data to process.
        """

        row = [field.strip() for field in line.split('|')]
        if row:
            # Remove the last element from the row
            row = row[:-1]
        gethistory.data_block.append(row)

# TimeFinishedState: Handles the final "time finished" section of the file. Transitions to EndState.
class TimeFinishedState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        Transitions from TimeFinishedState to the EndState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("changing to end state")
        gethistory.state = EndState()

    def doJob(self, gethistory, line):  
        """
        No specific processing in TimeFinishedState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file to process (not used in this state).
        """
        pass

# EndState: Final state in the state machine. No further transitions.
class EndState(GetHistoryState):
    
    def next_state(self, gethistory):
        """
        The final state in the processing flow. No further transitions.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
        """
        print("end state")

    def doJob(self, gethistory, line):  
        """
        No specific processing in EndState.
        
        Parameters:
            gethistory (GetHistory): The context controlling state transitions.
            line (str): The current line from the input file to process (not used in this state).
        """
        pass


