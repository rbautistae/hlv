from .gethistory_state import InitState, EndState, GetHistFileException
import csv


# Context class for handling the 'gethistory' file state transitions and CSV generation
class GetHistory: 
    def __init__(self, filePath, dstCSVPath):
        """
        Initializes the GetHistory context with the initial state (InitState), file paths, 
        and data structures to store field and data blocks.
        
        Parameters:
            filePath (str): Path to the input 'gethistory' file.
            dstCSVPath (str): Path where the output CSV file will be written.
        """
        self.state = InitState()  # Initial state is set to InitState
        self.filePath = filePath  # Path to the input file
        self.dstCSVPath = dstCSVPath  # Path to the output CSV file
        self.fields_block = []  # To store the fields between START-OF-FIELDS and END-OF-FIELDS
        self.data_block = []    # To store the data between START-OF-DATA and END-OF-DATA

    def next_state(self):
        """
        Transition to the next state in the state machine. This method delegates the state 
        transition to the current state's `next_state` method.
        """
        self.state.next_state(self)

    def doJob(self, line):
        """
        Processes the current line of input using the current state's logic.
        
        Parameters:
            line (str): The current line from the input file to be processed.
        """
        self.state.doJob(self, line)

    def get_csv(self):
        """
        Processes the 'gethistory' file and generates a CSV file with the captured data.

        Steps:
        - Reads the input file line by line.
        - Identifies key sections like START-OF-FILE, START-OF-FIELDS, START-OF-DATA, etc.
        - Validates that PROGRAMNAME is 'gethistory'.
        - Transitions between states based on the section.
        - Collects fields and data blocks.
        - Writes the final CSV file with header fields and data rows.
        
        Raises:
            GetHistFileException: If file structure does not match the estate diagram.
        """

        # Open the input file and start reading it line by line
        with open(self.filePath, 'r') as infile:
            for line in infile:
                # Remove leading and trailing spaces from the line
                line = line.strip()

                # Ignore comment lines starting with '#'
                if line.startswith('#'):
                    continue
                # Detect the start of the file and transition state
                elif line == 'START-OF-FILE':
                    self.next_state()
                # Transition states for field block section
                elif line == 'START-OF-FIELDS':
                    self.next_state()
                elif line == 'END-OF-FIELDS':
                    self.next_state()
                # Transition states for data block section
                elif line == 'START-OF-DATA':
                    self.next_state()
                elif line == 'END-OF-DATA':
                    self.next_state()
                # End of file detected, transition to final state
                elif line == 'END-OF-FILE':
                    self.next_state()
                # Process the line based on the current state
                else:
                    self.doJob(line)
        
        # Estate verification
        if not isinstance(self.state, EndState):
            raise GetHistFileException("The structure of the file is not correct. Verify blocks.")

        # Add predefined positional fields to the final header
        all_fields = ['id', 'returnCode', 'numberFields', 'date'] + self.fields_block

        # Write the collected data to the CSV file
        with open(self.dstCSVPath, 'w', newline='') as csvfile:
            csvwriter = csv.writer(csvfile)

            # Write the header (fields) to the CSV
            csvwriter.writerow(all_fields)

            # Write the data block to the CSV
            for row in self.data_block:
                csvwriter.writerow(row)



