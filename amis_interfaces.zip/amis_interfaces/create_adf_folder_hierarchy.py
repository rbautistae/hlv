# Databricks notebook source
import os
import shutil
import time
import csv
from datetime import datetime, timedelta

HOME = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/"

# Base directory
base_dir = f"{HOME}/data"

# Ensure the entire hierarchy does not already exist
if os.path.exists(base_dir):
    shutil.rmtree(base_dir)  # Remove the existing directory tree

# List of client IDs
clients = [
    # 'alad', 'aladp', 'aladpi', 'alph', 'amis', 'comp', 'deut', 'feda', 
    # 'manu', 'mce', 'nxdh', 'odrive', 'petr', 'sbwi', 'sbwip', 'scml', 
    'sfa', 'snb', 'strm'
]

# Unique interface names (each interface is different)
interfaces = [
    'am1234.56',
    # 'am5678.90',
    # 'am2345.67',
    # 'am6789.01',
    # 'am3456.78',
    # 'am7890.12',
    # 'am4567.89',
    # 'am8901.23',
    # 'am5678.12',
    # 'am6789.34',
    # 'am7890.45',
    # 'am8901.56',
    # 'am9012.67',
    # 'am0123.78',
    # 'am1234.89',
    # 'am2345.90',
    # 'am3456.01',
    # 'am4567.12',
    'am5678.23'
]

# Sample file names with extensions
file_types = ['data.json', 'config.xml', 'readme.txt']#, 'report.csv']

# Create the folder hierarchy and add files
for client, interface in zip(clients, interfaces):
    # Construct the directory path for each interface
    dir_path = os.path.join(base_dir, client, interface)
    # Create the directory if it doesn't exist
    os.makedirs(dir_path, exist_ok=True)
    
    # # Create example files within each interface folder
    # for file_name in file_types:
    #     file_path = os.path.join(dir_path, file_name)
    #     with open(file_path, 'w') as file:
    #         file.write(f"This is a sample {file_name.split('.')[-1]} file for {client} in {interface}.\n")

    # Optionally, create subfolders within each interface folder
    subfolders = ['subdir1', 'subdir2']
    for subfolder in subfolders:
        subdir_path = os.path.join(dir_path, subfolder)
        os.makedirs(subdir_path, exist_ok=True)
        
        # Add example files in subfolders as well
        for file_name in file_types:
            file_path = os.path.join(subdir_path, file_name)
            with open(file_path, 'w') as file:
                file.write(f"This is a sample {file_name.split('.')[-1]} file in {subfolder} for {client} in {interface}.\n")

        # Create 3 CSV files with different modification times
        for i in range(3):
            csv_file_name = f'report_{i+1}.csv'
            csv_file_path = os.path.join(dir_path, csv_file_name)
            # with open(csv_file_path, 'w') as file:
            #     file.write(f"This is CSV file {i+1} for {client} in {interface}.\n")

            # Sample data for CSV files
            data = [
                ["Column1", "Column2", "Column3"],
                [f"Data1_{i+1}", f"Data2_{i+1}", f"Data3_{i+1}"],
                [f"Data4_{i+1}", f"Data5_{i+1}", f"Data6_{i+1}"]
            ]
            
            # Write the sample data to the CSV file
            with open(csv_file_path, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(data)
                
            # Modify the file's timestamp to simulate different modification dates with minutes and seconds granularity
            now = datetime.now()
            mod_time = now - timedelta(days=i, minutes=i*5, seconds=i*30)  # Simulate different minutes and seconds
            mod_timestamp = mod_time.timestamp()
            os.utime(csv_file_path, (mod_timestamp, mod_timestamp))

print("Folder hierarchy with unique interfaces created successfully.")


# COMMAND ----------

