# Databricks notebook source
# MAGIC %md
# MAGIC #mount to be done

# COMMAND ----------

# df = spark.read.load("/mnt/inb/test/csvTest.csv", format="csv")
df


# COMMAND ----------

