# Databricks notebook source
# MAGIC %md
# MAGIC #Interface pattern matching

# COMMAND ----------

import re

# Interface regex pattern
interface_pattern = r'am\d{4}\.\d{2}'

# Sample strings to test
test_strings = [
    "am1234.56",  # Should match
    "am0000.00",  # Should match
    "am123.45",   # Should not match (only 3 digits before the decimal)
    "am12345.6",  # Should not match (5 digits before the decimal, 1 after)
    "bm1234.56",  # Should not match (doesn't start with 'am')
    "am1234.567", # Should not match (3 digits after the decimal)
]
# Test each string
for s in test_strings:
    if re.fullmatch(interface_pattern, s):
        print(f"'{s}' matches the pattern")
    else:
        print(f"'{s}' does not match the pattern")

# COMMAND ----------

