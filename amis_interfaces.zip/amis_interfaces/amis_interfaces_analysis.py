# Databricks notebook source
# MAGIC %md
# MAGIC #AMIS datasets schema obtention 
# MAGIC
# MAGIC
# MAGIC ##Prerrequisites
# MAGIC - 'Go here and get all schemas...'
# MAGIC     ![lala](/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/tejasImg.png)
# MAGIC - mount to be done
# MAGIC
# MAGIC ##Characteristics
# MAGIC - Connection to blob storage directly to get some data is not possible at the moment. There is no mount ('mnt') from eplorer workspace to amis blobstorages (unlike connecting to dih, which seems it's possible)
# MAGIC - Necessary to complete the scope (traverse all directories ? if not, which ones ? What files are relevant ? How many files are in scope ?)
# MAGIC - Initially, then, this work is considered an aproximation, or, let's say, a POC
# MAGIC - Some examples (files, datasets) are then selected from several interfaces, in order to work with them
# MAGIC - Nowadays is not possible to access the local workspace (with spark, dbutils, yes for pandas) for accessing to that subset of data in a comfortable way. 
# MAGIC - The access to volume has been configured. So, the source of the data will be in: 
# MAGIC   **/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/**
# MAGIC - 
# MAGIC

# COMMAND ----------

HOME = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/"
DEUT_DS = f"{HOME}/deut/LD Aladdin Accounts.LD HELVETIA schweizerische Lebensversicherungs- Aktiengesellschaft.20240830_20240831-034315_20240831-050156+0.csv"
NX_DS = f"{HOME}/nx/fedafin-Report-20240902-043531_20240902-043915+0.csv"

# DEUT_DS = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/deut/LD Aladdin Accounts.LD HELVETIA schweizerische Lebensversicherungs- Aktiengesellschaft.20240830_20240831-034315_20240831-050156+0.csv"
NX_DS = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/nx/fedafin-Report-20240902-043531_20240902-043915+0.csv"
# PICTET_DS = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/pictet/index_level_319_20240829 1.csv"


# COMMAND ----------

# MAGIC %md
# MAGIC # Traverse folders

# COMMAND ----------

import os
import re

# Interface regex pattern
interface_pattern = r'am\d{4}\.\d{2}'

def traverse_and_find_recent_csv(base_dir):
    # interfaces = {}
    
    # Dictionary to hold the most recent CSV file for each interface
    recent_csv_files = {}

    def recursive_traverse(current_path):
        # List all items in the current directory
        items = os.listdir(current_path)
        for item in items:
            item_path = os.path.join(current_path, item)
            if os.path.isdir(item_path):

                # interface folder identification
                if re.fullmatch(interface_pattern, item):
                    # Initialize the most recent CSV file tracking for this interface
                    recent_csv_files[item_path] = {'latest_file': None, 'latest_time': 0}
                
                # Recursively traverse subdirectories
                recursive_traverse(item_path)

            elif os.path.isfile(item_path):
                # Check for CSV files
                if item.endswith('.csv'):
                    parent_dir = os.path.dirname(item_path)
                    # Update the most recent CSV file for the current interface
                    for interface in recent_csv_files:
                        if parent_dir.startswith(interface):
                            file_time = os.path.getmtime(item_path)
                            if file_time > recent_csv_files[interface]['latest_time']:
                                recent_csv_files[interface]['latest_file'] = item_path
                                recent_csv_files[interface]['latest_time'] = file_time

    # Start the recursive traversal from the base directory
    recursive_traverse(base_dir)
    
    # Collect the most recent CSV files for each interface
    # TODO doesn't work ?
    most_recent_files = {}
    for interface_path, data in recent_csv_files.items():
        if data['latest_file']:
            most_recent_files[interface_path] = data['latest_file']

    return most_recent_files


HOME = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces"
# Base directory to start traversal
base_dir = f"{HOME}/data"

# Run the traversal and get the most recent CSV files
most_recent_files = traverse_and_find_recent_csv(base_dir)

# Print the most recent CSV file for each interface
print("\nMost recent CSV files for each interface:")
for interface, csv_file in most_recent_files.items():
    print(f"{interface}: {csv_file}")



# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType

# Define a list to hold schema information
schema_info = []

# Iterate over the dictionary of CSV files
for interface, csv_file in most_recent_files.items():
    try:
        # Load the CSV file into a DataFrame with inferred schema
        df = spark.read.csv(csv_file, header=True, inferSchema=True)
        
        # Extract the schema
        schema = df.schema
        
        # Convert schema to a string representation
        schema_str = str(schema)
        
        # Store schema information along with interface
        schema_info.append((interface, csv_file, schema_str))
        
        # Print schema for verification
        print(f"Schema for file {csv_file} in interface {interface}:")
        print(schema_str)
        
    except Exception as e:
        print(f"Error processing file {csv_file} in interface {interface}: {e}")

# Convert schema_info to a DataFrame
schema_df = spark.createDataFrame(schema_info, ["Interface", "FilePath", "Schema"])
schema_info


# COMMAND ----------

# MAGIC %md
# MAGIC #Test, workspace access problems

# COMMAND ----------

# MAGIC %md
# MAGIC #spark

# COMMAND ----------


df = spark.read.option("header", "true").option("inferSchema", "true").csv(NX_DS)
# df = spark.read.option("header", "true").option("inferSchema", "true").csv("file:/Workspace/Users/raul.bautistaerustes@helvetia.ch/amis_interfaces/nx/test.csv")
# df = spark.read.option("header", "true").option("inferSchema", "true").csv("/Workspace/Users/raul.bautistaerustes@helvetia.ch/amis_interfaces/nx/test.csv")
# df = spark.read.option("header", "true").option("inferSchema", "true").csv("./nx/test.csv")
# df = spark.read.option("header", "true").option("inferSchema", "true").csv("/mnt/Workspace/Users/raul.bautistaerustes@helvetia.ch/amis_interfaces/nx/test.csv")
# /Workspace/Users/raul.bautistaerustes@helvetia.ch/amis_interfaces/nx/test.csv
df.printSchema()


# COMMAND ----------

# MAGIC %md
# MAGIC ## Pandas 

# COMMAND ----------

NX_NAME_TEST = "/Workspace/Users/raul.bautistaerustes@helvetia.ch/amis_interfaces/nx/fedafin-Report-20240902-043531_20240902-043915+0.csv"
# NX_NAME_TEST = "/Workspace/Users/raul.bautistaerustes@helvetia.ch/amis_interfaces/nx/test.csv"


# COMMAND ----------

import pandas as pd

# COMMAND ----------

pandasDF = pd.read_csv(NX_NAME_TEST)
pandasDF

# COMMAND ----------

pandasDF.info()

# COMMAND ----------

sparkDF = spark.createDataFrame(pandasDF)
sparkDF.printSchema()
type(sparkDF)
