# Databricks notebook source
# %sql
# drop materialized view dham_dwa_explorer_devl.raul_bautista.mview_usage_detail;


# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog 'dham_dwa_explorer_devl';
# MAGIC SET legacy_time_parser_policy = legacy;
# MAGIC CREATE OR REPLACE VIEW raul_bautista.vw_usage_detail AS
# MAGIC -- SELECT * FROM raul_bautista.usage_detail_37583_202407 
# MAGIC -- UNION ALL
# MAGIC -- SELECT * FROM raul_bautista.usage_detail_37583_202408
# MAGIC
# MAGIC   with usage_detail as (
# MAGIC       SELECT * FROM  raul_bautista.usage_detail_37583_202407 
# MAGIC       UNION ALL
# MAGIC       SELECT * FROM raul_bautista.usage_detail_37583_202408
# MAGIC   )
# MAGIC
# MAGIC   select to_date(to_timestamp(PROCESSED_TIME, 'EEE MMM dd HH:mm:ss z yyyy')) as procDate, count(*) as howMany
# MAGIC   from usage_detail
# MAGIC   group by procDate
# MAGIC   having howMany > 50000
# MAGIC   order by procDate
# MAGIC
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC SET legacy_time_parser_policy = legacy;
# MAGIC use catalog 'dham_dwa_explorer_devl';
# MAGIC CREATE OR REPLACE MATERIALIZED VIEW raul_bautista.mvw_usage_detail 
# MAGIC -- COMMENT 'blabla'
# MAGIC -- SCHEDULE CRON '0 0 0 * * ? *'
# MAGIC AS
# MAGIC -- SELECT * FROM raul_bautista.usage_detail_37583_202407 
# MAGIC -- UNION ALL
# MAGIC -- SELECT * FROM raul_bautista.usage_detail_37583_202408
# MAGIC
# MAGIC   with usage_detail as (
# MAGIC       SELECT * FROM  raul_bautista.usage_detail_37583_202407 
# MAGIC       UNION ALL
# MAGIC       SELECT * FROM raul_bautista.usage_detail_37583_202408
# MAGIC   )
# MAGIC
# MAGIC   select to_date(to_timestamp(PROCESSED_TIME, 'EEE MMM dd HH:mm:ss z yyyy')) as procDate, count(*) as howMany
# MAGIC   from usage_detail
# MAGIC   group by procDate
# MAGIC   having howMany > 50000
# MAGIC   order by procDate
# MAGIC ;

# COMMAND ----------

# Load the XML data into a DataFrame
df = spark.read.format("csv").option("header", "true").load("/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/nx/fedafin-Report-20240902-043531_20240902-043915+0.csv")
# df = spark.read.format("xml").option("rowTag", "rootTag").load("/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/green_package/HLV-AGG.HLVTAG.HLV_CORE3_20240202 - onlyOne.xml")

display(df)

# COMMAND ----------

# Create a temporary view from the DataFrame
df.createOrReplaceTempView("temp_view")


# COMMAND ----------

# Create a materialized view from the temporary view
spark.sql("""
CREATE MATERIALIZED VIEW IF NOT EXISTS dham_dwa_explorer_devl.raul_bautista.materialized_view AS
SELECT * FROM temp_view
""")

# COMMAND ----------

