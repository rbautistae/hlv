# Databricks notebook source
# %sh 
# nslookup sap://vmdbh43s0helv.sap.az.helvetia.corp

# COMMAND ----------

# MAGIC %md
# MAGIC #Postgre

# COMMAND ----------

postgre_user = dbutils.secrets.get('RBauScope','PostgreUser')
postgre_pass = dbutils.secrets.get('RBauScope','PostgrePwd')

dfPost = (spark.read
  .format("jdbc")
  .option("driver","org.postgresql.Driver")
  .option("url", "jdbc:postgresql://pgsql-metadata-xdm-prod.postgres.database.azure.com:5432/postgres?autocommit=false")
  .option("dbtable", "assetmanagement.activity_audit")
  .option("user", postgre_user)
  .option("password", postgre_pass)
  .load()
)
display(dfPost)

# COMMAND ----------

# MAGIC %md
# MAGIC # SAP HANA BW

# COMMAND ----------

# shana_user = dbutils.secrets.get('RBauScope','SAPHANAUser')
# shana_pass = dbutils.secrets.get('RBauScope','SAPHANAPwd')
shana_user = dbutils.secrets.get('RBauScope','SAPHANATechUser')
shana_pass = dbutils.secrets.get('RBauScope','SAPHANATechUserPwd')

calc_view = '"_SYS_BIC"."system-local.bw.bw2hana/YAKEPPBI"'

df = (spark.read
  .format("jdbc")
  .option("driver","com.sap.db.jdbc.Driver")
  .option("url", "jdbc:sap://vmdbh43s0helv.sap.az.helvetia.corp:34353/?autocommit=false&encrypt=true&validateCertificate=false")
  .option("dbtable", '"_SYS_BIC"."system-local.bw.bw2hana/YAKEPPBI"')
  .option("user", shana_user)
  .option("password", shana_pass)
  .load()
)
display(df)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## example of connection (CHTI_CTH_DEVL user & another schema)
# MAGIC ##(works)

# COMMAND ----------

shana_user = dbutils.secrets.get('RBauScope','SAPHANAUser')
shana_pass = dbutils.secrets.get('RBauScope','SAPHANAPwd')

# host = "vmdbh43s0helv.sap.az.helvetia.corp"
df_table = (spark.read
  .format("jdbc")
  .option("driver","com.sap.db.jdbc.Driver")
  .option("url", "jdbc:sap://vmdbh43s0helv.sap.az.helvetia.corp:34353/?autocommit=false&encrypt=true&validateCertificate=false")
    .option("dbtable", "_SYS_BIC.XYHA34_YAMKDAL0") #works
  .option("user", shana_user)
  .option("password", shana_pass)
  .load()
)
display(df_table)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Continuation (once we have the data)

# COMMAND ----------

# MAGIC %md
# MAGIC ### testing data

# COMMAND ----------

# test data
# infering
SRC_DATA = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/sap_hana/test.csv"
df = spark.read.format("csv").option("header", True).option("inferSchema", True).load(SRC_DATA)
display(df)
df.printSchema()


# COMMAND ----------

# MAGIC %md
# MAGIC ### delta table creation

# COMMAND ----------

# delta table creation 
# TODO columns names changes

table = "dham_dwa_explorer_devl.raul_bautista.test_table"
df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(table)


# COMMAND ----------

# MAGIC %md
# MAGIC ### table verification

# COMMAND ----------

df2 = spark.read.table(table)
display(df2)
df2.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### view creation (not materialized)

# COMMAND ----------

# import pyspark.sql.functions as F

spark.sql("CREATE OR REPLACE  VIEW dham_dwa_explorer_devl.raul_bautista.vw_test_table AS SELECT * FROM dham_dwa_explorer_devl.raul_bautista.test_table")

# COMMAND ----------

# MAGIC %md
# MAGIC ### sql materialized view creation: make sense ? 

# COMMAND ----------

# MAGIC %sql
# MAGIC --required serverless warehouse
# MAGIC use catalog 'dham_dwa_explorer_devl'; 
# MAGIC CREATE OR REPLACE MATERIALIZED VIEW raul_bautista.mvw_test_table AS 
# MAGIC SELECT * FROM raul_bautista.test_table
# MAGIC ;

# COMMAND ----------

# MAGIC %md
# MAGIC ### spark materialized view creation: make sense ? 

# COMMAND ----------

spark.sql("CREATE OR REPLACE MATERIALIZED VIEW dham_dwa_explorer_devl.raul_bautista.mvw_test_table AS SELECT * FROM dham_dwa_explorer_devl.raul_bautista.test_table")

# COMMAND ----------

# YAKE table schema 


# from pyspark.sql.types import StructType, StructField, StringType, DecimalType, DateType

# schema = StructType([
#     StructField("DATE_SID", DateType(), True),
#     StructField("MONTH_TEXT", StringType(), True),
#     StructField("ASSET_CLASS", StringType(), True),
#     StructField("AAL_GROUP", StringType(), True),
#     StructField("GUV_GROUP", StringType(), True),
#     StructField("AAL_CONSO", StringType(), True),
#     StructField("LEDGER", StringType(), True),
#     StructField("COMPANY_CODE", StringType(), True),
#     StructField("GROUP_COMP_CODE", StringType(), True),
#     StructField("GROUP_ACCOUNT", StringType(), True),
#     StructField("LOCAL_ACCOUNT", StringType(), True),
#     StructField("CONSO_SEGMENT", StringType(), True),
#     StructField("PLANNING_GROUP", StringType(), True),
#     StructField("ID_NUMBER", StringType(), True),
#     StructField("CORE_ASSET_BD_L1", StringType(), True),
#     StructField("CORE_ASSET_BD_L2", StringType(), True),
#     StructField("CORE_ASSET_BD_L3", StringType(), True),
#     StructField("CORE_ASSET_BD_L4", StringType(), True),
#     StructField("CORE_ASSET_BD_L5", StringType(), True),
#     StructField("CORE_ASSET_BD_L6", StringType(), True),
#     StructField("INV_PORTF_KEY", StringType(), True),
#     StructField("IS_PARTICIPATING", StringType(), True),
#     StructField("FLAG_CONSOLIDATION", StringType(), True),
#     StructField("LOC_CURRCY", StringType(), True),
#     StructField("MARKET_VALUE_LC", DecimalType(17, 2), True),
#     StructField("MARK_TO_MARKET_LC", DecimalType(17, 2), True),
#     StructField("MARK_TO_MARKET_EXCL_FX_LC", DecimalType(17, 2), True),
#     StructField("MARK_TO_MARKET_FX_LC", DecimalType(17, 2), True),
#     StructField("CHANGE_UNREALIZED_LC", DecimalType(17, 2), True),
#     StructField("CHANGE_UNREALIZED_EXCL_FX_LC", DecimalType(17, 2), True),
#     StructField("OCI_CAPITAL_DELTA_EXCL_FX_LC", DecimalType(17, 2), True),
#     StructField("VALUATION_MARGIN_DELTA_LC", DecimalType(17, 2), True),
#     StructField("VALUATION_MARGIN_LC", DecimalType(17, 2), True),
#     StructField("VALUATION_MARGIN_PY_LC", DecimalType(17, 2), True),
#     StructField("OCI_DELTA_FX_LC", DecimalType(17, 2), True),
#     StructField("INVESTMENT_INCOME_LC", DecimalType(17, 2), True),
#     StructField("DIRECT_INCOME_LC", DecimalType(17, 2), True),
#     StructField("DI_INTEREST_LC", DecimalType(17, 2), True),
#     StructField("DI_CASH_LC", DecimalType(17, 2), True),
#     StructField("DI_ACCRUALS_LC", DecimalType(17, 2), True),
#     StructField("DI_SAC_INCOME_LC", DecimalType(17, 2), True),
#     StructField("SAC_ON_SALE_LC", DecimalType(17, 2), True),
#     StructField("SAC_ON_VALUATION_LC", DecimalType(17, 2), True),
#     StructField("SAC_CALCULATED_LC", DecimalType(17, 2), True),
#     StructField("EXPENSES_REAL_ESTATE_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_EX_ADD_REAL_PRICE_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_PRICE_REAL_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_VAL_I_PTR_LC", DecimalType(17, 2), True),
#     StructField("ADD_REAL_PRICE_LC", DecimalType(17, 2), True),
#     StructField("IMPAIR_NET_NEW_ECL_LC", DecimalType(17, 2), True),
#     StructField("IMPAIRMENT_BOOKED_LC", DecimalType(17, 2), True),
#     StructField("IMPAIRMENT_ESTIMATED_LC", DecimalType(17, 2), True),
#     StructField("FX_LC", DecimalType(17, 2), True),
#     StructField("R_G_FX_N_MON_ADD_RFX_P_LC", DecimalType(17, 2), True),
#     StructField("R_L_FX_NOT_MON_ADD_RFX_L_LC", DecimalType(17, 2), True),
#     StructField("ADDITIONAL_REALISATION_FX_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_FX_MONETARY_LC", DecimalType(17, 2), True),
#     StructField("INV_INCOME_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("DIR_INCOME_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("DI_INTEREST_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("DI_CASH_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("DI_ACCRUALS_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("DI_SAC_INCOME_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("SAC_ON_SALE_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("SAC_ON_VALUATION_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("SAC_CALCULATED_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("EXPENSES_REAL_ESTATE_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_E_ADD_R_PR_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_REAL_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_VAL_I_PTR_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("ADD_REAL_PRICE_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("IMPAIR_NET_NEW_ECL_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("IMPAIRMENT_BOOKED_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("IMPAIRMENT_ESTIMATED_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("FX_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("R_G_FX_N_MON_ADD_RFX_P_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("R_L_FX_N_MON_ADD_RFX_L_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("ADDITIONAL_REAL_FX_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_FX_MON_BUD_FY_LC", DecimalType(17, 2), True),
#     StructField("INVESTMENT_INCOME_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("DIR_INCOME_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("DI_INTEREST_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("DI_CASH_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("DI_ACCRUALS_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("DI_SAC_INCOME_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("SAC_ON_SALE_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("SAC_ON_VALUATION_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("SAC_CALCULATED_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("EXPENSES_REAL_ESTATE_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_E_ADD_R_PR_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_REAL_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("P_L_PRICE_VAL_I_PTR_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("ADD_REAL_PRICE_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("IMPAIR_NET_NEW_ECL_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("IMPAIRMENT_BOOKED_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("IMPAIRMENT_ESTIMATED_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("FX_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("R_G_FX_N_MON_ADD_RFX_P_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("R_L_FX_N_MON_ADD_RFX_L_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("ADDITIONAL_REAL_FX_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("PROFIT_LOSS_FX_MON_BUD_VT_LC", DecimalType(17, 2), True),
#     StructField("FX_UNDER_LC", DecimalType(17, 2), True),
#     StructField("FX_HEDGE_LC", DecimalType(17, 2), True),
#     StructField("PASSIVES_LC", DecimalType(17, 2), True)
# ])

    

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test

# COMMAND ----------

# # host = "vmdbh43s0helv.sap.az.helvetia.corp"
# calc_view = '"_SYS_BIC"."system-local.bw.bw2hana/YAKEPPBI"' # insufficient privilege
# # calc_view = '"_SYS_BIC"."system-local.bw.bw2hana/YAMKTEST"' # insufficient privilege
# # calc_view = '"_SYS_BIC"."system-local.bw.bw2hana/YAMKDTST"' # invalidated view
# df_table = (spark.read
#   .format("jdbc")
#   .option("driver","com.sap.db.jdbc.Driver")
#   .option("url", "jdbc:sap://vmdbh43s0helv.sap.az.helvetia.corp:34353/?autocommit=false&encrypt=true&validateCertificate=false")
#   .option("dbtable", calc_view)
#   # .option("dbtable", "select count(*) from _SYS_BIC.XYHA34_YAMKDAL0")
#   .option("user", shana_user)
#   .option("password", shana_pass)
#   .load()
# )

# COMMAND ----------

# MAGIC %md
# MAGIC ## From DIH team

# COMMAND ----------

# MAGIC %md
# MAGIC ## SQ_HANA_LOAD.py aproximation
# MAGIC - https://dev.azure.com/AssetManagementDataIntelligenceHub/_git/DataWarehousingAnalytics?path=/notebooks/hana/SQ_HANA_LOAD.py
# MAGIC - 

# COMMAND ----------


# dbTable = f"DPSTOHANADB.YGTFBA_LANDING_RUNCONTROL"
# driverClass = "com.sap.db.jdbc.Driver"
# url = "jdbc:sap://{urlHana}?user={your_username}&password={your_password}&encrypt=true&validateCertificate=false"

# urlHana = psHana["HANA_URL"]
# username = psHana["HANA_USERNAME"]
# password = dbutils.secrets.get(scope=psHana["SECRET_SCOPE"], key=psHana["SECRET_KEY"])

# mode = "append"
# dfControl.write.format("jdbc").mode(mode).option(
#     "url", url.format(urlHana=urlHana, your_username=username, your_password=password)
# ).option("dbtable", dbTable).option("driver", driverClass).save()

# from sap: 
# url
# username
# pwd
# table


# COMMAND ----------

