# Databricks notebook source
# MAGIC %pip install hdbcli

# COMMAND ----------

from hdbcli import dbapi  
# import ssl

# COMMAND ----------

# shana_user = dbutils.secrets.get('RBauScope','SAPHANAUser')
# shana_pass = dbutils.secrets.get('RBauScope','SAPHANAPwd')
shana_user = dbutils.secrets.get('RBauScope','SAPHANATechUser')
shana_pass = dbutils.secrets.get('RBauScope','SAPHANATechUserPwd')

# COMMAND ----------

# ssl_context = ssl.create_default_context()
# ssl_context.check_hostname = False
# ssl_context.verify_mode = ssl.CERT_NONE

# COMMAND ----------

conn = dbapi.connect(
    address="vmdbh43s0helv.sap.az.helvetia.corp", 
    port=34353, 
    validateCertificate=False,
    encrypt=True,
    # ssl=True,
    # url="jdbc:sap://vmdbh43s0helv.sap.az.helvetia.corp:34353/?autocommit=false&encrypt=true&validateCertificate=false",
    user=shana_user, 
    password=shana_pass
)
cursor = conn.cursor()

# COMMAND ----------

df_table.printSchema()

# COMMAND ----------

display(df_table)