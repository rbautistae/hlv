# Databricks notebook source
# MAGIC %md
# MAGIC # Pictet Indexes connection & download
# MAGIC
# MAGIC ## Characteristics: 
# MAGIC - 'Tactical' solution, temporary, until have definitive solution
# MAGIC - Get the data from d-2 (business day)
# MAGIC - url: https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2015&startDate=2024-09-01&endDate=2024-09-09
# MAGIC - 
# MAGIC
# MAGIC ## open points: 
# MAGIC - load initial snapshot (until 2015) ?
# MAGIC - 
# MAGIC
# MAGIC ## TODO: 
# MAGIC - review errors, exceptions...
# MAGIC - create lib, folder structure
# MAGIC - 

# COMMAND ----------

#destination
DST_VOLUME = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/pictet/"
DST_FILE_TMPL = "pictet_lpp2015.xlsx"

#pictet
# FILE_URL = "https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2000&startDate=2024-09-06"
# FILE_URL = "https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2015"
# FILE_URL = f"https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2015&startDate=" 
FILE_URL = f"https://am.pictet.com/api/gateways/publiccms-gateway/indices/export/language/en/family-code/lpp2015?start-date="


# COMMAND ----------

import datetime
import pandas
import requests
import shutil
import logging

# COMMAND ----------

# set up logging
FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
logging.basicConfig(format=FORMAT)
logger = logging.getLogger('pictet_download')
logger.setLevel(logging.DEBUG)


# COMMAND ----------


# business day-2
bdayminustwo = (datetime.datetime.today() - pandas.tseries.offsets.BDay(2))
logger.debug(bdayminustwo)
day = bdayminustwo.strftime('%Y-%m-%d')
logger.debug(day)
url = FILE_URL + day
logger.debug(url)
dst_path = f"{DST_VOLUME}{day}_{DST_FILE_TMPL}"
logger.debug(dst_path)

# simulate agent for avoiding HTTP 403
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
}

# COMMAND ----------

# download daily data into daily folder

response = requests.get(url, headers=headers)
if response.status_code == 200:
    # print('ok')
    # print(response.text)
    with open(dst_path, 'wb') as f:
        f.write(response.content)
        print('done')
else:
    print(f'Request failed with status code: {response.status_code}')



# COMMAND ----------

