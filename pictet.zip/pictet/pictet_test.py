# Databricks notebook source
# MAGIC %md
# MAGIC # Pictet Indexes connection to 
# MAGIC
# MAGIC ##Characteristics: 
# MAGIC - 'Tactical' solution, temporary, until have definitive solution
# MAGIC - Get the data from d-2 (business day)
# MAGIC - url: https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2015&startDate=2024-09-01&endDate=2024-09-09
# MAGIC - 
# MAGIC
# MAGIC ##open points: 
# MAGIC - load initial snapshot (until 2015) ?
# MAGIC - 

# COMMAND ----------

#get d-2 business day
business_day = "2024-09-09"

#destination
DST_VOLUME = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/pictet/"
DST_FILE_LPP2000 = f"{DST_VOLUME}pictet_file_lpp2000.xlsx"
DST_FILE_LPP2005 = f"{DST_VOLUME}pictet_file_lpp2005.xlsx"
DST_FILE_LPP2015 = f"{DST_VOLUME}pictet_file_lpp2015.xlsx"

#pictet
# FILE_URL = "https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2000&startDate=2024-09-06"
# FILE_URL = "https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2000&startDate=2024-09-06"
FILE_URL_LPP2000 = "https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2000"
FILE_URL_LPP2015 = "https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2015"
# FILE_URL = f"https://am.pictet/sitecore/api/ssc/Gateway-Controllers/Gateway/PAM/GetXLSDocument?code=lpp2015&startDate={business_day}" 
GENERAL_URL = "https://am.pictet/en/switzerland/articles/lpp-indices#overview"


# COMMAND ----------

# MAGIC %md
# MAGIC ## Test 1 (no agent specified, HTTP 403)

# COMMAND ----------

# import requests 

# response = requests.get(GENERAL_URL) 
# response


# COMMAND ----------

# MAGIC %md
# MAGIC ## Test 2

# COMMAND ----------

import requests
import shutil

# &startDate=2024-09-06
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
}

response = requests.get(FILE_URL_LPP2015, headers=headers)
if response.status_code == 200:
    # print('ok')
    # print(response.text)
    with open(DST_FILE_LPP2015, 'wb') as f:
        f.write(response.content)
        print('done')
else:
    print(f'Request failed with status code: {response.status_code}')



# COMMAND ----------

# MAGIC %md
# MAGIC ## Test 3, big file, no mem

# COMMAND ----------

import requests
import shutil

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
}

response = requests.get(FILE_URL_LPP2000, stream=True, headers=headers)

if response.status_code == 200:
    # print('ok')
    # print(response.text)
    with open(DST_FILE_LPP2015, 'wb') as f:
        for chunk in response.iter_content(chunk_size=1024*8): 
            if chunk:
                # print(f"Downloading {response.headers.get('content-length')} bytes...") 
                print(len(chunk)) 
                f.write(chunk)  
else:
    print(f'Request failed with status code: {response.status_code}')



# COMMAND ----------

