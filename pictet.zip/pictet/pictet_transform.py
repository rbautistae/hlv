# Databricks notebook source
# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Pictet Indexes transformation
# MAGIC
# MAGIC ##Characteristics: 
# MAGIC - Transform excel file from pictet to csv
# MAGIC - csv structure:
# MAGIC
# MAGIC     BFM_MARK_DATE_TIME,PRICE,CUSIP,PURPOSE,SOURCE\
# MAGIC     20240829,123.52,BEL1ARFX5,INXLEV,BRS\
# MAGIC     20240829,136.62,BEL1ARH47,INXLEV,BRS\
# MAGIC     20240829,155.97,BEL1ARH39,INXLEV,BRS
# MAGIC - 
# MAGIC
# MAGIC ## open points: 
# MAGIC - 
# MAGIC
# MAGIC ## TODO: 
# MAGIC - review errors, exceptions...
# MAGIC - create lib, folder structure
# MAGIC - 

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# src
SRC_VOLUME = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/pictet/"
SRC_FILE_TMPL = "pictet_lpp2015.xlsx"
# dst
DST_FILE_TMPL = "pictet_lpp2015.csv"


# COMMAND ----------

import datetime
import pandas as pd
import logging

# COMMAND ----------

# set up logging
FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
logging.basicConfig(format=FORMAT)
logger = logging.getLogger('pictet_transform')
logger.setLevel(logging.DEBUG)

# COMMAND ----------

# business day-2 (same than download nb)
bdayminustwo = (datetime.datetime.today() - pd.tseries.offsets.BDay(2))
logger.debug(bdayminustwo)
day = bdayminustwo.strftime('%Y-%m-%d')
logger.debug(day)

src_path = f"{SRC_VOLUME}{day}_{SRC_FILE_TMPL}"
logger.debug(src_path)


# COMMAND ----------

# def file_exists(path):
#     try:
#         dbutils.fs.ls(path)
#         return True
#     except Exception as e:
#         if 'java.io.FileNotFoundException' in str(e):
#             return False
#         else:
#             raise

# COMMAND ----------

# file_exists(src_path)

# COMMAND ----------

# excel parsing, characteristics:
# - Search for cell with 'Date' 
#     - data rows just below
#     - names just previous row
# - consider only daily tab (first one)
# - Necessary mapping name vs cusip 


# COMMAND ----------

# mapping excel content vs csv id (cusip)   
indexMapping = {
    'Pictet LPP 2015-25': 'BEL1ARFX5',
    'Pictet LPP 2015-40': 'BEL1ARH47',
    'Pictet LPP 2015-60': 'BEL1ARH39'
}

# COMMAND ----------

# indexMapping['Pictet LPP 2015-25']

# COMMAND ----------

# sheet name    
SHEET_NAME = 'Pictet LPP 2015 (daily)'
required_cols = [0,1,3,5]

# csv definition
dst_csv_schema = ['BFM_MARK_DATE_TIME', 'PRICE', 'CUSIP', 'PURPOSE', 'SOURCE']
# constant values in dst
PURPOSE_VALUE = 'INXLEV'
SOURCE_VALUE = 'BRS'

# COMMAND ----------

df_src = pd.read_excel(src_path, engine='openpyxl', sheet_name=SHEET_NAME, usecols = required_cols)
df_src

# COMMAND ----------

# row with 'Date' will be header
DATE_VALUE_INDEX = df_src.index[df_src.iloc[:, 0]=='Date'].to_list()[0]
df_src.iloc[DATE_VALUE_INDEX,1] = df_src.iloc[DATE_VALUE_INDEX - 1, 1] 
df_src.iloc[DATE_VALUE_INDEX,2] = df_src.iloc[DATE_VALUE_INDEX - 1, 2] 
df_src.iloc[DATE_VALUE_INDEX,3] = df_src.iloc[DATE_VALUE_INDEX - 1, 3] 
df_src

# COMMAND ----------

# clean rows 
df_src2 = df_src.drop(df_src.index[[0,1,2,3]])

# first row as header
df_src2.columns = df_src2.iloc[0]
df_src2 = df_src2[1:]

# reset row index
# TODO header index 4 ?!
df_src2 = df_src2.reset_index(drop=True)
df_src2

# COMMAND ----------

# df_src2.loc[0, 'Pictet LPP 2015-25']

# COMMAND ----------

# import datetime
# lala = '13/09/2024'
# datetime.datetime.strptime(lala, '%d/%m/%Y').strftime('%Y%m%d')

# COMMAND ----------

def get_row(df, index_name):
    try:
        # display(df)
        return pd.Series({
            'BFM_MARK_DATE_TIME':datetime.datetime.strptime(df.iloc[0,0], '%d/%m/%Y').strftime('%Y%m%d'), 
            'PRICE': df.loc[0, index_name], 
            'CUSIP':indexMapping[index_name], 
            'PURPOSE': PURPOSE_VALUE, 
            'SOURCE': SOURCE_VALUE})
    except Exception as e:
        logger.error(f"Error generating row for index '{index_name}'")
        raise

# COMMAND ----------

# create the dataset 3 rows
df_dst = pd.DataFrame(columns=dst_csv_schema)
df_dst.loc[0] = get_row(df_src2, 'Pictet LPP 2015-25')
df_dst.loc[1] = get_row(df_src2, 'Pictet LPP 2015-40')
df_dst.loc[2] = get_row(df_src2, 'Pictet LPP 2015-60')
df_dst

# COMMAND ----------


#TODO display fails if getting a price like '125.00', considered as LongType
try:
    display(df_dst)
except Exception as error:
    # handle the exception
    print("An exception occurred:", error) 
    print(df_dst)


# COMMAND ----------

# generate csv file
dst_path = f"{SRC_VOLUME}{day}_{DST_FILE_TMPL}"
logger.debug(dst_path)
df_dst.to_csv(dst_path, index=False)

# COMMAND ----------

