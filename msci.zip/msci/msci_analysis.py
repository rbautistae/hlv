# Databricks notebook source
# MAGIC %md
# MAGIC # Issuers

# COMMAND ----------

# MAGIC %sql
# MAGIC --overview
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.msci_issuer_reference_20250905
# MAGIC limit 10
# MAGIC ;

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.msci_issuer_reference_20250905"
)
display(df.describe())

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dham_dwa_explorer_devl.raul_bautista.msci_issuer_reference_20250905

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct ISSUERID) from dham_dwa_explorer_devl.raul_bautista.msci_issuer_reference_20250905

# COMMAND ----------

# MAGIC %md
# MAGIC ##Instruments

# COMMAND ----------

# MAGIC %sql
# MAGIC --overview
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905
# MAGIC limit 10
# MAGIC ;

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905"
)
display(df.describe())

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct LOOKUP_ID) from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905

# COMMAND ----------

# MAGIC %sql
# MAGIC select LOOKUP_ID, ISIN, count(*) as howMany
# MAGIC from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905
# MAGIC group by LOOKUP_ID, ISIN
# MAGIC having howmany>1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --select count(distinct ISIN)--1131710
# MAGIC select count(distinct lookup_id)--1497234
# MAGIC from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select isin, count(*) as howMany
# MAGIC from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905
# MAGIC group by isin
# MAGIC having howmany>1
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from dham_dwa_explorer_devl.raul_bautista.msci_instr_reference_wse_20250905
# MAGIC where isin='ZAE000000220'
# MAGIC
# MAGIC

# COMMAND ----------

