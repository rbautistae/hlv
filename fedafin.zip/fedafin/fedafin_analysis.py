# Databricks notebook source
# MAGIC %sql
# MAGIC --overview
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.fedafin_20220720_134026_issuer_ratings
# MAGIC limit 10
# MAGIC ;

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.fedafin_20220720_134026_issuer_ratings"
)
display(df.describe())

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dham_dwa_explorer_devl.raul_bautista.fedafin_20220720_134026_issuer_ratings

# COMMAND ----------

kanton_unique_count = df.select("bezeichnung").distinct().count()
display(kanton_unique_count)


# COMMAND ----------

emittent_id_count = df.select("emittent_id").distinct().count()
display(emittent_id_count)

# COMMAND ----------

name_count = df.select("name").distinct().count()
display(name_count)

# COMMAND ----------

# 1 is null -> not pk
uidcode_count = df.select("uidcode").distinct().count()
display(uidcode_count)

# COMMAND ----------

