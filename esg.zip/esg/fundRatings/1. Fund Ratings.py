# Databricks notebook source
# MAGIC %md
# MAGIC # Tables

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_20250109 limit 10;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Total rows, distinctness, potential key columns

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   COUNT(*) AS total_rows,
# MAGIC   COUNT(DISTINCT FUND_ID) AS distinct_fund_id,
# MAGIC   COUNT(DISTINCT FUND_SHARE_CLASS_ID) AS distinct_fund_share_class_id,
# MAGIC   COUNT(*) FILTER (WHERE FUND_SHARE_CLASS_ID IS NULL) AS null_fund_share_class_id
# MAGIC FROM
# MAGIC   dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_20250109;

# COMMAND ----------

# MAGIC %md
# MAGIC # Structure, describe

# COMMAND ----------

# MAGIC %sql 
# MAGIC DESCRIBE dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_20250109;

# COMMAND ----------

# MAGIC %md
# MAGIC # Volume

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS number_of_columns
# MAGIC FROM dham_dwa_explorer_devl.information_schema.columns
# MAGIC WHERE table_schema = 'raul_bautista'
# MAGIC   AND table_name = 'esg_9533_helvetia_fund_ratings_20250109';

# COMMAND ----------

