# Databricks notebook source
# MAGIC %md
# MAGIC # Tables

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select count(*)
# MAGIC select  r.FUND_SHARE_CLASS_ID, r.fund_id, r.fund_name, r.FUND_ISIN, r.AS_OF_DATE, 
# MAGIC         --r.FUND_ESG_COVERAGE, r.ESG_SOCIAL_SCORE, r.ESG_RATING_AAA, r.ESG_RATING_BBB, r.FUND_WEIGHTED_AVG_KEY_ISSUE_SCORE, 
# MAGIC         r.FUND_NAME, r.FUND_ISIN, r.FUND_MANAGER, r.FUND_OVERVIEW_NAME,
# MAGIC         'CLI', c.* except (FUND_SHARE_CLASS_ID, fund_id, fund_name, FUND_ISIN, AS_OF_DATE),
# MAGIC         'SUS', s.* except (FUND_SHARE_CLASS_ID, fund_id, fund_name, FUND_ISIN, AS_OF_DATE)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_20250109 as r
# MAGIC inner join dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_climate_change_20250109 as c
# MAGIC using (FUND_SHARE_CLASS_ID)
# MAGIC inner join dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_eu_sustainable_finance_20250109 as s
# MAGIC using (FUND_SHARE_CLASS_ID)
# MAGIC order by r.FUND_ID
# MAGIC --limit 10
# MAGIC ;

# COMMAND ----------

r_df = spark.table("dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_20250109")
c_df = spark.table("dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_climate_change_20250109")

result_df = r_df.join(c_df, on="FUND_SHARE_CLASS_ID", how="left_anti")
display(result_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Same exact rows ? (by FUND_SHARE_CLASS_ID)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT FUND_SHARE_CLASS_ID FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_20250109 
# MAGIC -- MINUS 
# MAGIC -- SELECT FUND_SHARE_CLASS_ID FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_climate_change_20250109
# MAGIC MINUS 
# MAGIC SELECT FUND_SHARE_CLASS_ID FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_fund_ratings_eu_sustainable_finance_20250109
# MAGIC ;

# COMMAND ----------

