# Databricks notebook source
# MAGIC %md
# MAGIC # Analysis sovereign data vs nxdh 
# MAGIC # (esg_9533_helvetia_sovereigns_20250109 vs nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sovereign dataset 

# COMMAND ----------

# MAGIC %sql
# MAGIC select ISSUER_ISIN, * 
# MAGIC from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ### number rows

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109

# COMMAND ----------

# MAGIC %md
# MAGIC ### no nulls issuer_isin

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
# MAGIC where ISSUER_ISIN is null

# COMMAND ----------

# MAGIC %md
# MAGIC ### different isin's

# COMMAND ----------

# MAGIC %sql
# MAGIC --all not null
# MAGIC select count(distinct ISSUER_ISIN)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
# MAGIC --where ISSUER_ISIN is not null

# COMMAND ----------

# MAGIC %md
# MAGIC ## NXDH dataset
# MAGIC - num rows: 10900
# MAGIC - without isin null: 9082
# MAGIC - num rows with distinct isin: 9053
# MAGIC - num rows with isin in sovereign: 29
# MAGIC - num rows with isin NOT in sovereign: 9024
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select isin, ISSUER, * 
# MAGIC from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ### number of rows

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### nxdh: some isins null !

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC where isin is not null 

# COMMAND ----------

# MAGIC %md
# MAGIC ### nxdh different isin's

# COMMAND ----------

# MAGIC %sql
# MAGIC -- all not null
# MAGIC select count(distinct isin)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC --where ISIN is not null

# COMMAND ----------

# MAGIC %md
# MAGIC ## Recon

# COMMAND ----------

# MAGIC %md
# MAGIC ### take out nxdh rows with null isin's

# COMMAND ----------

# MAGIC %sql 
# MAGIC select  n.ISIN, 
# MAGIC         e.ISSUER_ISIN, e.ISSUER_NAME
# MAGIC from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0 n
# MAGIC left join dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109 e
# MAGIC on n.ISIN = e.issuer_isin
# MAGIC where n.ISIN is not null
# MAGIC order by n.ISIN

# COMMAND ----------

# MAGIC %md
# MAGIC ## set operators

# COMMAND ----------

# MAGIC %md
# MAGIC ### common isins

# COMMAND ----------

# MAGIC %sql 
# MAGIC select  n.ISIN from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0 n
# MAGIC where isin is not null
# MAGIC
# MAGIC intersect
# MAGIC
# MAGIC select issuer_isin from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109 e
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### isin in nxdh not in sovereign

# COMMAND ----------

# MAGIC %sql 
# MAGIC select  n.ISIN from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0 n
# MAGIC where isin is not null
# MAGIC
# MAGIC minus
# MAGIC
# MAGIC select issuer_isin from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109 e
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ### issuer_isin in sovereign not in nxdh

# COMMAND ----------

# MAGIC %sql 
# MAGIC select issuer_isin from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109 e
# MAGIC
# MAGIC minus
# MAGIC
# MAGIC select  n.ISIN from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0 n
# MAGIC where isin is not null
# MAGIC

# COMMAND ----------

