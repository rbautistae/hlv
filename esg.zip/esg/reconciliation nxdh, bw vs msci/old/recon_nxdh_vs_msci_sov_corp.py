# Databricks notebook source
# MAGIC %md
# MAGIC # Analysis nxdh isin's vs esg corp&sov issuer_isin's

# COMMAND ----------

# %sql
# describe dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_corporates_20250109

# COMMAND ----------

# MAGIC %sql
# MAGIC --obtention of all sov & corp data
# MAGIC with sov (
# MAGIC   select 'sov' as type, issuer_isin as isin, issuer_name
# MAGIC   from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
# MAGIC )
# MAGIC ,corp (
# MAGIC   select 'corp' as type, issuer_isin as isin, issuer_name
# MAGIC   from dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_corporates_20250109
# MAGIC )
# MAGIC ,allEsg (
# MAGIC   --sov & corp
# MAGIC   select *
# MAGIC   from sov 
# MAGIC   union
# MAGIC   select * 
# MAGIC   from corp
# MAGIC )
# MAGIC -- select count(*) from allEsg --order by issuer_name
# MAGIC
# MAGIC select nx.isin, esg.issuer_name, esg.type
# MAGIC from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0 nx
# MAGIC left join allEsg esg
# MAGIC using (isin)
# MAGIC where nx.isin is not null
# MAGIC --and esg.type is not null
# MAGIC --and esg.type = 'sov'
# MAGIC order by esg.issuer_name
# MAGIC ;
# MAGIC

# COMMAND ----------

