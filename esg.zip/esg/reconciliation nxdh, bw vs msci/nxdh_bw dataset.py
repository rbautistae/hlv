# Databricks notebook source
# DBTITLE 1,e


# COMMAND ----------

# MAGIC %md
# MAGIC # Analysis esg isin universe vs nxdh/bw's

# COMMAND ----------

# MAGIC %md
# MAGIC ## NXDH/BW dataset
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select isin, ISSUER, * 
# MAGIC --from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC from dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ### number of rows

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC -- from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC from dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### isins null

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC -- from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC from dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC where isin is not null 

# COMMAND ----------

# MAGIC %md
# MAGIC ### different isin's

# COMMAND ----------

# MAGIC %sql
# MAGIC -- all not null
# MAGIC select count(distinct isin)
# MAGIC -- from dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC from dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC --where ISIN is not null