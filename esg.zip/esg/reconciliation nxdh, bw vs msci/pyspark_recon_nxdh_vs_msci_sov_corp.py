# Databricks notebook source
# MAGIC %md
# MAGIC # (pyspark version)
# MAGIC # Analysis nxdh/bw isin's vs esg corp&sov issuer_isin's

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

# MAGIC %sql
# MAGIC   SELECT distinct(issuer_isin) as isin
# MAGIC   FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC where isin in (
# MAGIC   SELECT distinct(issuer_isin) as isin
# MAGIC   FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
# MAGIC   -- FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_corporates_20250109
# MAGIC )
# MAGIC

# COMMAND ----------

# Load data into DataFrames
sov_df = spark.sql(
    """
    SELECT 'sov' AS type, issuer_isin as isin, issuer_name
    FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_sovereigns_20250109
    """
)

corp_df = spark.sql(
    """
    SELECT 'corp' AS type, issuer_isin as isin, issuer_name
    FROM dham_dwa_explorer_devl.raul_bautista.esg_9533_helvetia_corporates_20250109
    """
)
print (sov_df.count())
print (corp_df.count())
# display(sov_df)
# display(corp_df)

# Union of sovereign and corporate data
all_df = sov_df.union(corp_df)
display(all_df)
print (all_df.count())


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT isin, client_id, DESC_INSTMT, SEC_DESC2
# MAGIC -- FROM dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC FROM dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC
# MAGIC limit 2
# MAGIC     

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*)
# MAGIC -- FROM dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
# MAGIC FROM dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
# MAGIC where isin is null

# COMMAND ----------


# Load master dataset WITOUT DUP ISINs (exist)
master_df = spark.sql(
    """
    SELECT distinct isin, DESC_INSTMT
    -- FROM dham_dwa_explorer_devl.raul_bautista.nxdh_secm_all_am_2807_04_20250120174526_20250120_164952_0
    FROM dham_dwa_explorer_devl.raul_bautista.secm_all_am_0033_01_20250121_20250121_173340_0
    """
)

result_df = master_df.join(
    all_df,
    "isin",
    "left"
).filter(
    col("isin").isNotNull()
).select(
    col("isin"), col("issuer_name"), col("type")
).orderBy("issuer_name")

# result_df.show()
print(result_df.count())
display(result_df)


# COMMAND ----------

# MAGIC %md
# MAGIC # Set operations & analysis result datasets

# COMMAND ----------

# Perform set operations
# 1. ISINs in master_df not existing in all_df
master_not_in_all_df = master_df.join(
    all_df,
    "isin",
    "left_anti"
)

# 2. ISINs in sov_df not existing in master_df
sov_not_in_master_df = sov_df.join(
    master_df,
    "isin",
    "left_anti"
)

# 3. ISINs in corp_df not existing in master_df
corp_not_in_master_df = corp_df.join(
    master_df,
    "isin",
    "left_anti"
)

# 4. ISINs that exist in both all_df and master_df
isins_in_both_df = master_df.join(
    all_df,
    "isin",
    "inner"
)

print("ISINs in master_df not in all_df:")
print(master_not_in_all_df.count())
display(master_not_in_all_df)

print("ISINs in sov_df not in master_df:")
print(sov_not_in_master_df.count())
display(sov_not_in_master_df)

print("ISINs in corp_df not in master_df:")
print(corp_not_in_master_df.count())
display(corp_not_in_master_df)

print("ISINs  in both all_df and master_df:")
print(isins_in_both_df.count())
display(isins_in_both_df)

# COMMAND ----------

