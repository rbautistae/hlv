# Databricks notebook source
# MAGIC %sql
# MAGIC --entries for a product
# MAGIC select *
# MAGIC except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC from dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities   
# MAGIC where GSA_DELETEDFLAG = 0 
# MAGIC       and pcl_g_id = '528123ef-6ca4-47a4-865c-65764fe49ad0'
# MAGIC ;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --get all valid customers
# MAGIC select count(*)
# MAGIC --except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC from dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities val
# MAGIC join dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC on val.ConnectionEntityId = cus.CST_G_ID 
# MAGIC where val.ConnectionEntityType = 'ICustomer'
# MAGIC       and val.GSA_DELETEDFLAG = 0 
# MAGIC       and cus.GSA_DELETEDFLAG = 0
# MAGIC       -- and 
# MAGIC       -- pcl_g_id = '528123ef-6ca4-47a4-865c-65764fe49ad0'
# MAGIC ;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --select all different customers
# MAGIC select count (distinct CST_G_ID)
# MAGIC from dham_dwa_gsa_intg.cfpetra.customer 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --select valid different customers
# MAGIC --difference: some customers have different products ?
# MAGIC select count(distinct ConnectionEntityId) as validDifferentCus, count(ConnectionEntityId) as validCus
# MAGIC from dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities
# MAGIC where ConnectionEntityType = 'ICustomer'
# MAGIC       and GSA_DELETEDFLAG = 0
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- valid customers with >1 product
# MAGIC select pcl_g_id, ConnectionEntityType, count(*) as howMany
# MAGIC from dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities
# MAGIC group by pcl_g_id, ConnectionEntityType
# MAGIC having  ConnectionEntityType = 'ICustomer' 
# MAGIC         and howMany > 1
# MAGIC --      and GSA_DELETEDFLAG = 0
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --customer relations for the customer 
# MAGIC select CPR_G_PERSON_ID, *
# MAGIC except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC from dham_dwa_gsa_intg.cfpetra.customer_person_relation
# MAGIC where CPR_G_CUSTOMER_ID = '50ce800a-7fca-4673-86c9-f6bd6b0d54be'
# MAGIC

# COMMAND ----------

# MAGIC %sql 
# MAGIC describe dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities

# COMMAND ----------

