# Databricks notebook source
# MAGIC %md
# MAGIC # CLONED

# COMMAND ----------

import logging
import sys
from pyspark.sql import DataFrame

#############################################################################################################
#   SETUP LOGGING
#############################################################################################################
log_level = logging.WARN
logging.basicConfig(
    level=log_level,  # Set the logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s - %(levelname)s - %(message)s',  # Set the log message format
)
log = logging.getLogger()
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
log.addHandler(handler)
log.setLevel(log_level)

#############################################################################################################
#   DEFINE FUNCTIONS
#############################################################################################################
def get_data_technical(full_table_name: str, tech_col_prefix:str, pk_col: str, date_col_name:str = "LOAD_DATE") -> DataFrame:
    query = f"""
        WITH DATA_TECHNICAL AS (
            SELECT
                *,
                /* WE CHANGE THE GRANULARITY TO A FULL DAY THEREFORE WE TRUNCATE THE TIME PART OF THE TS */
                DATE_TRUNC('DAY', {tech_col_prefix}_VALIDFROM_TS) AS {tech_col_prefix}_VALIDFROM_DATE,
                /* WE CHANGE THE GRANULARITY TO A FULL DAY, IF IT IS END OF TIME THEN WE KEEP IT, OTHERWISE WE TAKE END OF DAY OF DAY BEFORE */
                CASE
                    WHEN {tech_col_prefix}_VALIDTO_TS = '9999-12-31T23:59:59.999+00:00' THEN {tech_col_prefix}_VALIDTO_TS
                    ELSE DATEADD(MICROSECOND, -1, DATE_TRUNC('DAY', {tech_col_prefix}_VALIDTO_TS))
                END AS {tech_col_prefix}_VALIDTO_DATE
            FROM {full_table_name}
            WHERE
                /* DELETED RECORDS ARE ADDED AS A NEW VERSION BUT WITH A DELETED FLAG SO WE IGNORE THEM */
                {tech_col_prefix}_DELETEDFLAG = 0
        ),
        DATE_RANGE AS (
        SELECT
            EXPLODE(SEQUENCE({date_col_name}, CURRENT_DATE)) AS {date_col_name}
        FROM
            (
            SELECT
                MIN({tech_col_prefix}_VALIDFROM_DATE) AS {date_col_name}
            FROM
                DATA_TECHNICAL
            )
        ),
        TECHNICAL_LOAD_TIME_SERIES AS (
        SELECT
            dra.{date_col_name},
            dat.*
        FROM
            DATE_RANGE dra
            JOIN DATA_TECHNICAL dat
                ON dra.{date_col_name} BETWEEN dat.{tech_col_prefix}_VALIDFROM_DATE AND dat.{tech_col_prefix}_VALIDTO_DATE
        )
        SELECT
        *
        FROM
            TECHNICAL_LOAD_TIME_SERIES
        ORDER BY
            {date_col_name},
            {pk_col};
    """
    log.info(query)
    df = spark.sql(query)
    return df

def get_data_business(technical_table_name: str, valid_from_col_name: str, valid_to_col_name: str, deleted_col_name: str, date_col_name:str = "LOAD_DATE") -> DataFrame:
    query = f"""
        WITH DATA_BUSINESS AS(
            SELECT
                *,
                /* WE CHANGE THE GRANULARITY TO A FULL DAY THEREFORE WE TRUNCATE THE TIME PART OF THE TS */
                DATE_TRUNC('DAY', {valid_from_col_name}) AS {valid_from_col_name}_DATE,
                /* WE CHANGE THE GRANULARITY TO A FULL DAY, IF IT IS END OF TIME THEN WE KEEP IT */
                CASE    
                    WHEN {valid_to_col_name} = '9999-12-31T23:59:59.999+00:00' THEN {valid_to_col_name}
                    ELSE DATEADD(MICROSECOND, -1, DATE_TRUNC('DAY', {valid_to_col_name}))
                END AS {valid_to_col_name}_DATE,
                /* WE CHANGE THE GRANULARITY TO A FULL DAY, IF IT IS NULL WE KEEP IT */
                CASE
                    WHEN {deleted_col_name} IS NULL THEN {deleted_col_name}
                    ELSE DATE_TRUNC('DAY', {deleted_col_name})
                END AS {deleted_col_name}_DATE
            FROM
                {technical_table_name}
        )
        SELECT
            *
        FROM
            DATA_BUSINESS
        WHERE
            /* IF THE RELEVANT DATE (LOAD_DATE) IS BETWEEN BUSINESS VALID FROM AND BUSINESS VALID TO THEN THE RECORD IS RELEVANT ON THAT SPECIFIC DATE */
            {date_col_name} BETWEEN {valid_from_col_name}_DATE AND {valid_to_col_name}_DATE AND
            /* IF THE RELEVANT DATE (LOAD_DATE) IS AFTER BUSINESS DELETED ON THEN THE RECORD IS NOT RELEVANT ON THAT SPECIFIC DATE */
            /* TODO: IS THE RECORD STILL VALID ON THE DAY OF IT'S DELETION? IF SO THEN <= */
            /* TODO: INSTEAD OF FILTERING OUT THE NON VALID BUS RECORDS WE COULD PROVIDE THE IS_BUS_VALID AS FLAG BECAUSE IT MIGHT BE THAT WE NEED ALL DATA THAT IS TECHNICAL VALID ON THAT DAY BUT NEED TO DECIDE IF WE WANT BUS OR TECH VALIDITY */
            /* TODO: LOGIC NEEDS TO BE CHECKED IF THERE ARE MULTIPLE INTRADAY CHANGES IF STILL THE BUS VALID RECORD IS RETURNED */
            /* INFO: SHOULD HOLD STAND, VALIDATED WITH REAL_ESTATE --> REE_S_ID_PUBLIC = 'REA-112272548' AND LOAD_DATE = '2025-04-13' THIS HAS 4 INTRADAY CHANGES AND LATEST IS RETURNED */
            {date_col_name} < COALESCE({deleted_col_name}_DATE, '9999-12-31T23:59:59.999+00:00');
    """
    log.info(query)
    df = spark.sql(query)
    return df

def register_temp_view(df: DataFrame, view_name:str) -> None:
    df.createOrReplaceTempView(view_name)
    print(f"view_name: '{view_name}'") #rbe
    df.write.mode("overwrite").saveAsTable(f"dham_dwa_explorer_devl.raul_bautista.{view_name}") #rbe

def register_temp_views(table_definition:dict) -> None:
    for(table_name, table) in table_definition.items():
        is_enabled = table["is_enabled"]
        if is_enabled:
            tbl_name_tech = f"{table_name}_TECH"
            print(f"loading: '{tbl_name_tech}'")
            df_tech = get_data_technical(table["table"], table["tech_prefix"], table["pk"])
            table["df_tech"] = df_tech
            register_temp_view(df_tech, tbl_name_tech)
            print(f"loaded: '{tbl_name_tech}' with {df_tech.count()} rows")

            has_bus_validity = table["has_bus_validity"]
            if has_bus_validity:
                tbl_name_bus = f"{table_name}_BUS"
                print(f"loading: '{tbl_name_bus}'")
                df_bus = get_data_business(tbl_name_tech, table["bus_from_col"], table["bus_to_col"], table["bus_del_col"], table["date_col"])
                register_temp_view(df_bus, tbl_name_bus)
                print(f"loaded: '{tbl_name_bus}' with {df_bus.count()} rows")
                print()
            else:
                print(f"skipping: '{table_name}' has no business validity")
        # break #rbe

def check_unique(view_name: str, bus_col_prefix:str, date_col_name: str = "LOAD_DATE"):
    query = f"""
        SELECT
            {date_col_name},
            COUNT({bus_col_prefix}_G_ID) AS TOTAL_GUID,
            COUNT(DISTINCT {bus_col_prefix}_G_ID) AS TOTAL_DISTINCT_GUID,
            COUNT(DISTINCT {bus_col_prefix}_S_ID_PUBLIC) AS TOTAL_DISTINCT_PUBLIC_ID,
            COUNT({bus_col_prefix}_S_ID_PUBLIC) - COUNT(DISTINCT {bus_col_prefix}_S_ID_PUBLIC) AS DUPLICATES
        FROM
            {view_name}
        GROUP BY
            {date_col_name}
        ORDER BY
            {date_col_name};
        """

# COMMAND ----------

table_definition = {
    "FUNDING": {
        "table": "dham_dwa_gsa_intg.cfpetra.funding",
        "pk": "FUN_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "FUN_D_VALID_FROM_ON",
        "bus_to_col": "FUN_D_VALID_TO",
        "bus_del_col": "FUN_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": False
    },
    "CREDIT_CHECK": {
        "table": "dham_dwa_gsa_intg.cfpetra.credit_check",
        "pk": "CCH_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "CCH_D_VALID_FROM_ON",
        "bus_to_col": "CCH_D_VALID_TO",
        "bus_del_col": "CCH_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": False
    },
    "CONTRACT_DEFINITION": {
        "table": "dham_dwa_gsa_intg.cfpetra.contract_definition",
        "pk": "COD_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "COD_D_VALID_FROM_ON",
        "bus_to_col": "COD_D_VALID_TO",
        "bus_del_col": "COD_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": False
    },
    "REAL_ESTATE": {
        "table": "dham_dwa_gsa_intg.cfpetra.real_estate",
        "pk": "REE_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "REE_D_VALID_FROM_ON",
        "bus_to_col": "REE_D_VALID_TO",
        "bus_del_col": "REE_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": True
    },
    "APPRAISEMENT": {
        "table": "dham_dwa_gsa_intg.cfpetra.appraisement",
        "pk": "APP_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "APP_D_VALID_FROM_ON",
        "bus_to_col": "APP_D_VALID_TO",
        "bus_del_col": "APP_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": True
    },
    "REAL_SECURITY": {
        "table": "dham_dwa_gsa_intg.cfpetra.real_security",
        "pk": "RSE_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "RSE_D_VALID_FROM_ON",
        "bus_to_col": "RSE_D_VALID_TO",
        "bus_del_col": "RSE_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": False
    },
    "CUSTOMER": {
        "table": "dham_dwa_gsa_intg.cfpetra.customer",
        "pk": "CST_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": "CST_D_VALID_FROM_ON",
        "bus_to_col": "CST_D_VALID_TO",
        "bus_del_col": "CST_D_DELETED_ON",
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": True,
        "is_enabled": False
    },
    "VALID_ENTITY_IDENTIFIERS": {
        "table": "dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities",
        "pk": "PCL_G_ID",
        "tech_prefix": "GSA",
        "bus_from_col": None,
        "bus_to_col": None,
        "bus_del_col": None,
        "date_col": "LOAD_DATE",
        "df_tech": None,
        "df_bus": None,
        "has_bus_validity": False,
        "is_enabled": True
    },
}
register_temp_views(table_definition)

# COMMAND ----------

# MAGIC %sql
# MAGIC describe dham_dwa_gsa_intg.cfpetra.real_estate;

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   This is validation, that for each real estate identity we have in the
# MAGIC   designated product -> entity view, we are able to find the guid used
# MAGIC   on real estate side, for the given load date. So far we have no
# MAGIC   miss match.
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   veit.LOAD_DATE AS VEIT_LOAD_DATE,
# MAGIC   veit.PCL_G_ID,
# MAGIC   veit.ConnectionEntityType,
# MAGIC   veit.ConnectionEntityId,
# MAGIC   reet.REE_G_ID,
# MAGIC   reet.LOAD_DATE AS REET_LOAD_DATE
# MAGIC FROM
# MAGIC   VALID_ENTITY_IDENTIFIERS_TECH veit 
# MAGIC LEFT JOIN
# MAGIC   REAL_ESTATE_TECH reet
# MAGIC ON
# MAGIC   veit.ConnectionEntityId = reet.REE_G_ID AND
# MAGIC   veit.LOAD_DATE = reet.LOAD_DATE
# MAGIC WHERE
# MAGIC   ConnectionEntityType = 'IRealEstate'
# MAGIC   AND reet.REE_G_ID IS NULL

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   This is proof, that we have more then one guid for the same 
# MAGIC   real estate entity (guid vs public id) per load date from a 
# MAGIC   technical perspective.
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   LOAD_DATE,
# MAGIC   REE_S_ID_PUBLIC,
# MAGIC   COUNT(*) AS REE_ENTRIES
# MAGIC FROM
# MAGIC   REAL_ESTATE_TECH
# MAGIC GROUP BY
# MAGIC   LOAD_DATE,
# MAGIC   REE_S_ID_PUBLIC
# MAGIC HAVING
# MAGIC   COUNT(*) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   We pick one real estate public id from above to get the guids
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   REAL_ESTATE_TECH
# MAGIC WHERE
# MAGIC   LOAD_DATE = '2025-04-09'
# MAGIC   AND REE_S_ID_PUBLIC = 'REA-112277570'

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   We see which id is active from a product perspective
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   VALID_ENTITY_IDENTIFIERS_TECH
# MAGIC WHERE
# MAGIC   LOAD_DATE = '2025-04-09'
# MAGIC   AND ConnectionEntityType = 'IRealEstate'
# MAGIC   AND ConnectionEntityId IN (
# MAGIC     '4ef53ccb-9845-433a-96dc-6626ee1e61ad',
# MAGIC     '5a559e88-35f0-470b-8b64-04e00e090fcf',
# MAGIC     'dcc0e662-69f9-47cd-82f4-47695af8b134'
# MAGIC   )

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   We check the guid we see as the valid one on our BUS data and
# MAGIC   apparently for this case we come up with the same guid.
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   REAL_ESTATE_BUS
# MAGIC WHERE
# MAGIC   LOAD_DATE = '2025-04-09'
# MAGIC   AND REE_S_ID_PUBLIC = 'REA-112277570'

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   Here we try to figure out if our selection for the business valid
# MAGIC   entry on real estate does come up with the same result as the 
# MAGIC   identity view we get from finovo.
# MAGIC   The result is proof, that not in every case we can determine the
# MAGIC   valid real estate object per date
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   veit.LOAD_DATE AS VEIT_LOAD_DATE,
# MAGIC   veit.PCL_G_ID,
# MAGIC   veit.ConnectionEntityType,
# MAGIC   veit.ConnectionEntityId,
# MAGIC   reeb.REE_G_ID,
# MAGIC   reeb.LOAD_DATE AS REET_LOAD_DATE
# MAGIC FROM
# MAGIC   VALID_ENTITY_IDENTIFIERS_TECH veit
# MAGIC LEFT JOIN
# MAGIC   REAL_ESTATE_BUS reeb
# MAGIC ON
# MAGIC   veit.ConnectionEntityId = reeb.REE_G_ID AND
# MAGIC   veit.LOAD_DATE = reeb.LOAD_DATE
# MAGIC WHERE
# MAGIC   ConnectionEntityType = 'IRealEstate'
# MAGIC   AND reeb.REE_G_ID IS NULL

# COMMAND ----------

# MAGIC %sql
# MAGIC /************************************************************************
# MAGIC   In this example we see that the business validity of the real estate
# MAGIC   is set to 2025-02-03, so why from a product perspective this on is
# MAGIC   valid is not clear and we cannot determine the logic. Conclusion is, 
# MAGIC   that we need to load multiple RE objects into gold per day and flag
# MAGIC   the one that is valid for the day based on the finovo view
# MAGIC ************************************************************************/
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   REAL_ESTATE_TECH
# MAGIC WHERE
# MAGIC   (REE_G_ID = '1516b896-e9ea-4514-a3e1-81a0d8902292'
# MAGIC   OR REE_S_ID_PUBLIC = 'REA-112274238')
# MAGIC   AND LOAD_DATE = '2025-05-07'

# COMMAND ----------

# MAGIC %sql
# MAGIC -- CREATE OR REPLACE TEMP VIEW FULL_REAL_ESTATE_DATA AS
# MAGIC CREATE OR REPLACE VIEW dham_dwa_explorer_devl.raul_bautista.vw_mortgages_FULL_REAL_ESTATE_DATA AS
# MAGIC   WITH VALID_IDENTIFIERS AS (
# MAGIC     SELECT DISTINCT -- WE NEED DISTINCT SINCE MULTIPLE PRODUCTS CAN BE LINKED TO THE SAME REAL ESTATE OR APPRAISEMENT
# MAGIC       veit.LOAD_DATE,
# MAGIC       veit.ConnectionEntityType,
# MAGIC       veit.ConnectionEntityId
# MAGIC     FROM
# MAGIC       dham_dwa_explorer_devl.raul_bautista.VALID_ENTITY_IDENTIFIERS_TECH veit --rbe
# MAGIC   ),
# MAGIC   REAL_ESTATE_DATA AS (
# MAGIC     SELECT
# MAGIC       reei.LOAD_DATE AS REE_LOAD_DATE,
# MAGIC       reei.ConnectionEntityId AS REE_G_ID,
# MAGIC       reei.ConnectionEntityType AS REE_CONN_TYPE,
# MAGIC       reet.REE_S_ID_PUBLIC,
# MAGIC       reet.REE_S_ID_LOGICAL,
# MAGIC       reet.REE_S_REFERENCE_ID_WUP,
# MAGIC       reet.REE_S_REAL_ESTATE_TYPE,
# MAGIC       reet.REE_S_REAL_ESTATE_USAGE,
# MAGIC       reet.REE_S_ADDRESS_LOCATION_NAME,
# MAGIC       reet.REE_S_ADDRESS_POSTCODE,
# MAGIC       reet.REE_S_ADDRESS_STREET,
# MAGIC       reet.REE_S_ADDRESS_HOUSE_NUMBER,
# MAGIC       reet.REE_S_ADDRESS_CANTON,
# MAGIC       reet.REE_S_ADDRESS_FLOOR,
# MAGIC       reet.REE_S_ADDRESS_COUNTRY,
# MAGIC       reet.REE_S_OWNERSHIP_STRUCTURE,
# MAGIC       reet.REE_N_PERCENTAGE_OF_COMMERCIAL_SPACE
# MAGIC     FROM
# MAGIC       VALID_IDENTIFIERS reei
# MAGIC         LEFT JOIN dham_dwa_explorer_devl.raul_bautista.REAL_ESTATE_TECH reet --rbe
# MAGIC           ON reet.LOAD_DATE = reei.LOAD_DATE
# MAGIC           AND reet.REE_G_ID = reei.ConnectionEntityId
# MAGIC     WHERE
# MAGIC       reei.ConnectionEntityType = 'IRealEstate'
# MAGIC   ),
# MAGIC   APPRAISEMENT_DATA AS (
# MAGIC     SELECT
# MAGIC       appi.LOAD_DATE AS APP_LOAD_DATE,
# MAGIC       appi.ConnectionEntityId APP_G_ID,
# MAGIC       appi.ConnectionEntityType APP_CONN_TYPE,
# MAGIC       appt.APP_S_REAL_ESTATE_ID,
# MAGIC       appt.APP_S_ID_PUBLIC,
# MAGIC       appt.APP_S_REAL_ESTATE_LOGICAL_ID,
# MAGIC       appt.APP_N_HAS_BUILD_PERMIT,
# MAGIC       appt.APP_N_RIGHT_OF_RESIDENCE,
# MAGIC       appt.APP_N_USUFRUCT,
# MAGIC       appt.APP_D_TERM_FROM,
# MAGIC       appt.APP_S_CONTAMINATED,
# MAGIC       appt.APP_N_LOAN_VALUE_RATIO_BASE,
# MAGIC       appt.APP_N_PURCHASE_PRICE,
# MAGIC       appt.APP_D_PURCHASE_PRICE_ON
# MAGIC     FROM
# MAGIC       VALID_IDENTIFIERS appi
# MAGIC         LEFT JOIN dham_dwa_explorer_devl.raul_bautista.APPRAISEMENT_TECH appt --rbe
# MAGIC           ON appt.LOAD_DATE = appi.LOAD_DATE
# MAGIC           AND appt.APP_G_ID = appi.ConnectionEntityId
# MAGIC     WHERE
# MAGIC       appi.ConnectionEntityType = 'IAppraisement'
# MAGIC   )
# MAGIC   SELECT
# MAGIC     *
# MAGIC   FROM
# MAGIC     REAL_ESTATE_DATA reed
# MAGIC       LEFT JOIN APPRAISEMENT_DATA appd
# MAGIC         ON appd.APP_S_REAL_ESTATE_LOGICAL_ID = reed.REE_S_ID_LOGICAL
# MAGIC         AND appd.APP_LOAD_DATE = reed.REE_LOAD_DATE

# COMMAND ----------

# MAGIC %sql
# MAGIC /***********************************************************************************************
# MAGIC   THIS IS VERIFICATION, THAT
# MAGIC ***********************************************************************************************/
# MAGIC SELECT
# MAGIC   REE_LOAD_DATE,
# MAGIC   REE_S_ID_PUBLIC,
# MAGIC   COUNT(*) AS RECORD_COUNT
# MAGIC FROM
# MAGIC   -- FULL_REAL_ESTATE_DATA
# MAGIC   dham_dwa_explorer_devl.raul_bautista.vw_mortgages_FULL_REAL_ESTATE_DATA --rbe
# MAGIC GROUP BY
# MAGIC   REE_LOAD_DATE,
# MAGIC   REE_S_ID_PUBLIC
# MAGIC HAVING
# MAGIC   COUNT(*) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   REE_LOAD_DATE AS LOAD_DATE,                                                             -- DO WE NEED TO REMOVE ONE DAY BECAUSE WE LOAD T-1 AND THE RECORD WE SEE NOW IS EOD FROM THE DAY BEFORE?
# MAGIC   REE_S_ID_PUBLIC AS REAL_ESTATE_ID,
# MAGIC   REE_G_ID AS REAL_ESTATE_ALT_1_ID,
# MAGIC   REE_S_ID_LOGICAL AS REAL_ESTATE_ALT_2_ID,
# MAGIC   REE_S_REFERENCE_ID_WUP AS REAL_ESTATE_ALT_3_ID,
# MAGIC   APP_S_ID_PUBLIC AS REAL_ESTATE_ALT_4_ID,
# MAGIC   APP_G_ID AS REAL_ESTATE_ALT_5_ID,
# MAGIC   NULL AS REAL_ESTATE_ALT_6_ID,
# MAGIC   NULL AS MANDATE_ID,                                                                     -- WHERE DO WE GET THE MANDATE ID FROM?
# MAGIC   REE_S_ADDRESS_POSTCODE AS POST_CODE,
# MAGIC   REE_S_ADDRESS_LOCATION_NAME AS CITY,
# MAGIC   REE_S_ADDRESS_CANTON AS STATE_CODE,
# MAGIC   CASE
# MAGIC     WHEN REE_S_ADDRESS_COUNTRY = 'CH' THEN 'CHE'
# MAGIC     WHEN REE_S_ADDRESS_COUNTRY = '' OR REE_S_ADDRESS_COUNTRY IS NULL THEN
# MAGIC       CASE
# MAGIC         WHEN REE_S_ADDRESS_CANTON IN
# MAGIC           ('AG', 'AR', 'AI', 'BL', 'BS', 'BE', 'FR', 'GE', 'GL', 'GR', 'JU', 'LU', 'NE', 'NW', 'OW', 'SG', 'SH', 'SZ',  'SO', 'TG', 'TI', 'UR', 'VD', 'VS', 'ZG', 'ZH')
# MAGIC           THEN 'CHE'
# MAGIC         ELSE REE_S_ADDRESS_COUNTRY
# MAGIC       END
# MAGIC     ELSE REE_S_ADDRESS_COUNTRY
# MAGIC   END AS COUNTRY_CODE,
# MAGIC   REE_N_PERCENTAGE_OF_COMMERCIAL_SPACE AS COMMERCIAL_SURFACE_AREA_PERCENTAGE,
# MAGIC   APP_D_TERM_FROM AS APPRAISEMENT_DATE,
# MAGIC   APP_N_LOAN_VALUE_RATIO_BASE AS APPRAISEMENT_VALUE,
# MAGIC   'CHF' AS APPRAISEMENT_CURRENCY,
# MAGIC   APP_N_PURCHASE_PRICE AS PURCHASE_PRICE,
# MAGIC   APP_D_PURCHASE_PRICE_ON AS PURCHASE_DATE,
# MAGIC   'CHF' AS PURCHASE_CURRENCY,
# MAGIC   CASE
# MAGIC     WHEN APP_S_CONTAMINATED IS NULL THEN -1 -- Unknown
# MAGIC     WHEN APP_S_CONTAMINATED = '' THEN -1 -- Unknown
# MAGIC     WHEN APP_S_CONTAMINATED = 'Unknown' THEN -1 -- Unknown
# MAGIC     WHEN APP_S_CONTAMINATED = 'Yes' THEN 1 -- Yes
# MAGIC     WHEN APP_S_CONTAMINATED = 'No' THEN 0 -- No
# MAGIC     ELSE 0
# MAGIC   END AS CONTAMINATED,
# MAGIC   CASE
# MAGIC     WHEN APP_N_HAS_BUILD_PERMIT IS NULL THEN -1 -- Unknown
# MAGIC     WHEN APP_N_HAS_BUILD_PERMIT = 0 THEN 0 -- No
# MAGIC     WHEN APP_N_HAS_BUILD_PERMIT = 1 THEN 1 -- Yes
# MAGIC     ELSE 0
# MAGIC   END AS RIGHT_OF_CONSTRUCTION,
# MAGIC   CASE
# MAGIC     WHEN APP_N_RIGHT_OF_RESIDENCE IS NULL THEN -1 -- Unknown
# MAGIC     WHEN APP_N_RIGHT_OF_RESIDENCE = 0 THEN 0 -- No
# MAGIC     WHEN APP_N_RIGHT_OF_RESIDENCE = 1 THEN 1 -- Yes
# MAGIC     ELSE 0
# MAGIC   END AS RIGHT_OF_RESIDENCE,
# MAGIC   CASE
# MAGIC     WHEN APP_N_USUFRUCT IS NULL THEN -1 -- Unknown
# MAGIC     WHEN APP_N_USUFRUCT = 0 THEN 0 -- No
# MAGIC     WHEN APP_N_USUFRUCT = 1 THEN 1 -- Yes
# MAGIC     ELSE 0
# MAGIC   END AS USUFRUCT
# MAGIC FROM
# MAGIC   -- FULL_REAL_ESTATE_DATA
# MAGIC   dham_dwa_explorer_devl.raul_bautista.vw_mortgages_FULL_REAL_ESTATE_DATA --rbe
# MAGIC WHERE
# MAGIC   REE_S_ID_PUBLIC IN ('REA-112274238', 'REA-112278232', 'REA-108849582')
# MAGIC ORDER BY
# MAGIC   REE_S_ID_PUBLIC, REE_LOAD_DATE;

# COMMAND ----------

