# Databricks notebook source
# MAGIC %md
# MAGIC ###additional_collateralXXX

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct 
# MAGIC ADP_S_ADDITIONAL_COLLATERAL_TYPE
# MAGIC from dham_dwa_gsa_intg.chpetra.additional_collateral_person
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC ADP_S_ID_PUBLIC as COLLATERAL_ID, 
# MAGIC ADP_G_ID as COLLATERAL_ALT_1_ID,
# MAGIC ADP_S_ADDITIONAL_COLLATERAL_TYPE as COLLATERAL_TYPE,
# MAGIC ADP_D_TERM_FROM as INTIIAL_TERM_START_DT,
# MAGIC ADP_D_TERM_TO as INTIIAL_TERM_AND_DT,
# MAGIC ADP_D_DATED as SURRENDER_VAL_DT,
# MAGIC ADP_N_SURRENDER_VALUE as SURRENDER_AMOUNT,
# MAGIC 'CHF' as SURRENDER_AMOUNT_CRNCY,
# MAGIC ADP_N_INSURED_AMOUNT as INSURED_AMOUNT,
# MAGIC 'CHF' as INSURED_AMOUNT_CRNCY
# MAGIC
# MAGIC ,CASE
# MAGIC 	-- WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE in ('Unknown') THEN -1 ¿?¿?
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'AccountFoundationWithFond' THEN 10
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'VestedPensionBenefits2' THEN 30
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'AccountFoundationWithoutFond' THEN 40
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'AcpSpecial' THEN 60
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'DeathRiskPolicy3a' THEN 70
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'DeathRiskPolicy3b' THEN 80
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'JointSecurity' THEN 90
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'LifeInsuranceRestrictedPension3aWithFond' THEN 100
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'LifeInsuranceRestrictedPension3aWithoutFond' THEN 110
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'LifeInsuranceUnrestrictedPension3bWithFond' THEN 120
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'LifeInsuranceUnrestrictedPension3bWithoutFond' THEN 130
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'VestedBenefitsAccount' THEN 140
# MAGIC 	WHEN ADP_S_ADDITIONAL_COLLATERAL_TYPE == 'BuildingInsurancePolicy' THEN 200
# MAGIC   -- ELSE -2 ¿?¿?
# MAGIC END as COLLATERAL_TYPE
# MAGIC
# MAGIC from dham_dwa_gsa_intg.chpetra.additional_collateral_person
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC ADR_S_ID_PUBLIC as COLLATERAL_ID,
# MAGIC ADR_G_ID as COLLATERAL_ALT_1_ID,
# MAGIC ADR_S_ADDITIONAL_COLLATERAL_TYPE as COLLATERAL_TYPE, 
# MAGIC ADR_D_TERM_FROM as INTIIAL_TERM_START_DT,
# MAGIC ADR_D_TERM_TO as INTIIAL_TERM_AND_DT,
# MAGIC ADR_D_DATED as SURRENDER_VAL_DT,
# MAGIC ADR_N_INSURED_AMOUNT as INSURED_AMOUNT
# MAGIC from dham_dwa_gsa_intg.chpetra.additional_collateral_real_estate
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC ADP_S_ID_PUBLIC as COLLATERAL_ID, 
# MAGIC ADP_G_ID as COLLATERAL_ALT_1_ID
# MAGIC ,'person' as source
# MAGIC from dham_dwa_gsa_intg.chpetra.additional_collateral_person
# MAGIC
# MAGIC union 
# MAGIC
# MAGIC select 
# MAGIC ADR_S_ID_PUBLIC as COLLATERAL_ID,
# MAGIC ADR_G_ID as COLLATERAL_ALT_1_ID
# MAGIC ,'realEstate' as source
# MAGIC from dham_dwa_gsa_intg.chpetra.additional_collateral_real_estate
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###funding

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC FUN_S_ID_PUBLIC as COLLATERAL_ALT_2_ID,
# MAGIC FUN_G_ID as COLLATERAL_ALT_3_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.funding
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###contract_definition

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC COD_S_ID_PUBLIC as COLLATERAL_ALT_4_ID,
# MAGIC COD_G_ID as COLLATERAL_ALT_5_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.contract_definition
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###pension_fund

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC PEF_S_ID_PUBLIC as MANDATE_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.pension_fund
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###contract_definition_note

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC MAX(CDN_S_TYPE),
# MAGIC MAX(CDN_D_REFERENCE_DATE),
# MAGIC SUM(CDN_N_AMOUNT)
# MAGIC from dham_dwa_gsa_intg.chpetra.contract_definition_note
# MAGIC limit 2

# COMMAND ----------

