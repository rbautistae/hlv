# Databricks notebook source
# MAGIC %md
# MAGIC ###product_completion

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC PCL_S_ID_PUBLIC as INSTRUMENT_ID,
# MAGIC PCL_G_ID as INSTRUMENT_ALT_1_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.product_completion
# MAGIC limit 2
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###funding

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC null as INSTRUMENT_ALT_2_ID,
# MAGIC FUN_S_ID_PUBLIC as INSTRUMENT_ALT_3_ID,
# MAGIC FUN_G_ID as INSTRUMENT_ALT_4_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.funding
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###contract_definition

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC COD_S_ID_PUBLIC as INSTRUMENT_ALT_5_ID,
# MAGIC COD_G_ID as INSTRUMENT_ALT_6_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.contract_definition
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###pension_fund

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC PEF_S_ID_PUBLIC as MANDATE_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.pension_fund
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ###value field (quant, green_package)

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from dham_dwa_gsa_intg.chpetra.mtg_quant_valuation
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select distinct PCL_S_ID_PUBLIC
# MAGIC -- from dham_dwa_gsa_intg.chpetra.product_completion
# MAGIC -- select distinct mtg_quant_valuation.prd_id
# MAGIC -- from dham_dwa_gsa_intg.chpetra.mtg_quant_valuation
# MAGIC select  quant.prd_id, 
# MAGIC         quant.yield_to_maturity_quant,
# MAGIC         quant.clean_market_value,
# MAGIC         quant.dirty_market_value
# MAGIC , *
# MAGIC --kind of join, etc...?
# MAGIC from dham_dwa_gsa_intg.chpetra.mtg_quant_valuation as quant
# MAGIC join dham_dwa_gsa_intg.chpetra.product_completion as pro
# MAGIC on quant.prd_id = pro.PCL_S_ID_PUBLIC
# MAGIC limit 2

# COMMAND ----------

# MAGIC %md
# MAGIC ### how to link with alad green package ?

# COMMAND ----------

# MAGIC %sql
# MAGIC select MKT_VALUE, CLIENT_ID, ISSUER_ID
# MAGIC , *
# MAGIC from dham_dwa_gsa_intg.cfalad.alad_green_package_analytics
# MAGIC limit 2
# MAGIC

# COMMAND ----------

