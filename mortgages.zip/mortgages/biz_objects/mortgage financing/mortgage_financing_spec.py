# Databricks notebook source
# MAGIC %md
# MAGIC ###IS_SECURITIZATION_POSSIBLE

# COMMAND ----------

# MAGIC %sql
# MAGIC select COD_S_SECURITIZATION_POSSIBLE,
# MAGIC     CASE
# MAGIC       WHEN COD_S_SECURITIZATION_POSSIBLE in ('', 'Unknown') THEN -1
# MAGIC       WHEN COD_S_SECURITIZATION_POSSIBLE == 'Yes' THEN 1
# MAGIC       WHEN COD_S_SECURITIZATION_POSSIBLE == 'No' THEN 0
# MAGIC       ELSE -2
# MAGIC     END as IS_SECURITIZATION_POSSIBLE
# MAGIC from dham_dwa_gsa_intg.chpetra.contract_definition 
# MAGIC limit 2
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###ETP_RULE_001

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   CASE 
# MAGIC     WHEN CCH_S_COMPETENCE_Finovo IN ('No') AND CCH_S_Affordability_Allowed IN ('No', 'NoEtp') THEN 1
# MAGIC     ELSE 0
# MAGIC   END as ETP_RULE_001
# MAGIC   ,CCH_S_COMPETENCE_Finovo, CCH_S_Affordability_Allowed,  *
# MAGIC FROM dham_dwa_gsa_intg.chpetra.credit_check
# MAGIC limit 20
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###ETP_RULE_002

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   CASE 
# MAGIC     WHEN CCH_S_COMPETENCE_Finovo IN ('No') AND CCH_S_Loan_Value_Ratio_Observed IN ('No', 'NoEtp') THEN 1
# MAGIC     ELSE 0
# MAGIC   END as ETP_RULE_002
# MAGIC   ,CCH_S_COMPETENCE_Finovo, CCH_S_Loan_Value_Ratio_Observed,  *
# MAGIC FROM dham_dwa_gsa_intg.chpetra.credit_check
# MAGIC limit 20
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###ETP_RULE_003

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   CASE 
# MAGIC     WHEN CCH_S_COMPETENCE_Finovo IN ('No') AND CCH_S_Loan_Value_Ratio_Gross_Observed IN ('No') THEN 1
# MAGIC     ELSE 0
# MAGIC   END as ETP_RULE_003
# MAGIC   ,CCH_S_COMPETENCE_Finovo, CCH_S_Loan_Value_Ratio_Observed,  *
# MAGIC FROM dham_dwa_gsa_intg.chpetra.credit_check
# MAGIC limit 20
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###ETP_RULE_004

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   CASE 
# MAGIC     WHEN CCH_S_COMPETENCE_Finovo IN ('No') AND CCH_N_OBJECT_PROFIT_ALLOWED IN (0) THEN 1
# MAGIC     ELSE 0
# MAGIC   END as ETP_RULE_004
# MAGIC   ,CCH_S_COMPETENCE_Finovo, CCH_N_OBJECT_PROFIT_ALLOWED,  *
# MAGIC FROM dham_dwa_gsa_intg.chpetra.credit_check
# MAGIC limit 20
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###ETP_RULE_005

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   CASE 
# MAGIC     WHEN CCH_S_COMPETENCE_Finovo IN ('No') AND CCH_S_GWG_ALLOWED IN (0) THEN 1
# MAGIC     ELSE 0
# MAGIC   END as ETP_RULE_005
# MAGIC   ,CCH_S_COMPETENCE_Finovo, CCH_S_GWG_ALLOWED,  *
# MAGIC FROM dham_dwa_gsa_intg.chpetra.credit_check
# MAGIC limit 20
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###ORGAN_CREDIT_FLAG

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT FUN_S_CLOSE_FUNDING_PARTNER
# MAGIC FROM dham_dwa_gsa_intg.chpetra.funding
# MAGIC -- limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   CASE 
# MAGIC     WHEN FUN_S_CLOSE_FUNDING_PARTNER='No' THEN 1
# MAGIC     WHEN FUN_S_CLOSE_FUNDING_PARTNER='Yes' THEN 0
# MAGIC     ELSE -2
# MAGIC   END as ORGAN_CREDIT_FLAG
# MAGIC   ,FUN_S_CLOSE_FUNDING_PARTNER, *
# MAGIC FROM dham_dwa_gsa_intg.chpetra.funding
# MAGIC limit 20
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###MORTGAGE_RANK_POSITION (clarify with Karine: RSE_S_REAL_ESTATE_LOGICAL_ID ?!)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SELECT
# MAGIC --   CASE 
# MAGIC --     WHEN FUN_S_CLOSE_FUNDING_PARTNER='No' THEN 1
# MAGIC --     WHEN FUN_S_CLOSE_FUNDING_PARTNER='Yes' THEN 0
# MAGIC --     ELSE -2
# MAGIC --   END as ORGAN_CREDIT_FLAG
# MAGIC --   ,FUN_S_CLOSE_FUNDING_PARTNER, *
# MAGIC -- FROM dham_dwa_gsa_intg.chpetra.funding
# MAGIC -- limit 20
# MAGIC
# MAGIC --  LOGIC BASED ON MAIL FROM LUKA (FINOVO)
# MAGIC --  AS WELL AS SPECIFICATION FROM LEA AND KARINE
# MAGIC SELECT *
# MAGIC   -- MAX(RSE_S_POSITION)
# MAGIC FROM
# MAGIC   dham_dwa_gsa_intg.chpetra.real_security
# MAGIC -- WHERE
# MAGIC --   RSE_S_REAL_ESTATE_LOGICAL_ID = '65b58aaa-398f-4bde-bb44-ca6147758ede'
# MAGIC   -- AND RSE_S_CREDITOR = 'MortgageLendor'
# MAGIC   -- AND RSE_N_IS_VALID_VERSION = '1' 
# MAGIC   -- AND RSE_D_DELETED_ON IS NULL
# MAGIC   -- AND LOAD_DATE BETWEEN RSE_D_VALID_FROM_ON AND RSE_D_VALID_TO
# MAGIC limit 2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT distinct RSE_S_POSITION
# MAGIC FROM
# MAGIC   dham_dwa_gsa_intg.chpetra.real_security
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- product_completion
# MAGIC -- customer
# MAGIC -- credit_check
# MAGIC -- person
# MAGIC -- adress_item
# MAGIC -- lsv_iddentification
# MAGIC -- lsv_debit_authorization
# MAGIC
# MAGIC

# COMMAND ----------

