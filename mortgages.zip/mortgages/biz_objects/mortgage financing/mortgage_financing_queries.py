# Databricks notebook source
# MAGIC %md
# MAGIC ###

# COMMAND ----------

# MAGIC %md
# MAGIC ###Basics

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC FUN_S_ID_PUBLIC,
# MAGIC FUN_G_ID,
# MAGIC FUN_S_ID_LOGICAL,
# MAGIC FUN_N_MORTGAGE_AMOUNT,
# MAGIC FUN_N_PRE_AMOUNT,
# MAGIC FUN_S_CLOSE_FUNDING_PARTNER --conversion
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.funding 
# MAGIC limit 2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC COD_S_ID_PUBLIC,
# MAGIC COD_G_ID,
# MAGIC COD_S_ID_LOGICAL,
# MAGIC COD_D_VALID_FROM_ON,
# MAGIC COD_D_VALID_TO,
# MAGIC COD_S_SECURITIZATION_POSSIBLE --conversion
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.contract_definition 
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC CCH_S_ID_PUBLIC,
# MAGIC CCH_G_ID,
# MAGIC CCH_S_ID_LOGICAL,
# MAGIC CCH_N_LOAN_VALULE_RATIO, 
# MAGIC CCH_N_AFFORDABILITY_EXCL_CREDIT_SCORE,
# MAGIC CCH_N_OBJECT_PROFIT_PERCENT,
# MAGIC CCH_N_AFFORDABILITY_RELEVANT_INCOME
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.credit_check 
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC INO_S_INCOME_OR_OUTGO_TYPE,--conversion
# MAGIC INO_S_INCOME_OUTGO_TYPE,--conversion
# MAGIC INO_N_AMOUNT
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.income_outgo 
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC PEF_S_ID_PUBLIC
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.pension_fund 
# MAGIC limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC PER_S_ID_PUBLIC,
# MAGIC PER_G_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.person 
# MAGIC limit 2

# COMMAND ----------

# funding
# contract_definition
# credit_check
# pension_fund
# income_outgo
# person

# COMMAND ----------

# MAGIC %md
# MAGIC ###FINANCING_MORTGAGE

# COMMAND ----------

# MAGIC %sql
# MAGIC -- # select 
# MAGIC -- # FUN_S_ID_PUBLIC,
# MAGIC -- # FUN_G_ID,
# MAGIC -- # FUN_S_ID_LOGICAL,
# MAGIC -- # FUN_N_MORTGAGE_AMOUNT,
# MAGIC -- # FUN_N_PRE_AMOUNT,
# MAGIC -- # FUN_S_CLOSE_FUNDING_PARTNER --conversion
# MAGIC -- # ,*
# MAGIC -- # from dham_dwa_gsa_intg.cfpetra.funding 
# MAGIC -- # limit 2
# MAGIC
# MAGIC -- # select 
# MAGIC -- # COD_S_ID_PUBLIC,
# MAGIC -- # COD_G_ID,
# MAGIC -- # COD_S_ID_LOGICAL,
# MAGIC -- # COD_D_VALID_FROM_ON,
# MAGIC -- # COD_D_VALID_TO,
# MAGIC -- # COD_S_SECURITIZATION_POSSIBLE --conversion
# MAGIC -- # ,*
# MAGIC -- # from dham_dwa_gsa_intg.cfpetra.contract_definition 
# MAGIC -- # limit 2
# MAGIC
# MAGIC
# MAGIC select 
# MAGIC FUN_S_ID_PUBLIC, FUN_G_ID, FUN_S_ID_LOGICAL, FUN_N_MORTGAGE_AMOUNT, FUN_N_PRE_AMOUNT, FUN_S_CLOSE_FUNDING_PARTNER, --conversion
# MAGIC CCH_S_ID_PUBLIC, CCH_G_ID, CCH_S_ID_LOGICAL, CCH_N_LOAN_VALULE_RATIO, CCH_N_AFFORDABILITY_EXCL_CREDIT_SCORE, CCH_N_OBJECT_PROFIT_PERCENT, CCH_N_AFFORDABILITY_RELEVANT_INCOME
# MAGIC --,*
# MAGIC from dham_dwa_gsa_intg.chpetra.funding 
# MAGIC left join dham_dwa_gsa_intg.chpetra.credit_check 
# MAGIC on fun_s_id_logical = cch_g_funding_logical_id
# MAGIC limit 10

# COMMAND ----------

# MAGIC %md
# MAGIC ###CUSTOMER_MORTGAGE_PARTY_FINANCIAL
# MAGIC