# Databricks notebook source
# MAGIC %sql
# MAGIC --relation customer vs address_item
# MAGIC   select ADI_S_COUNTRY, *
# MAGIC   from dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC   join dham_dwa_gsa_intg.cfpetra.address_item addr
# MAGIC   on addr.ADI_S_PARENT_ID = cus.CST_S_ID_LOGICAL
# MAGIC   where addr.ADI_S_PARENT_TYPE = 'ICustomer'
# MAGIC   limit 2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --customer vs funding
# MAGIC select FUN_S_PERSON_GROUP, *
# MAGIC from dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC join dham_dwa_gsa_intg.cfpetra.funding fun
# MAGIC on cus.CST_G_ID = fun.FUN_S_CUSTOMER_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC -- customer_person_relation
# MAGIC select CPR_G_PERSON_ID as personId--, * 
# MAGIC --except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC from dham_dwa_gsa_intg.cfpetra.customer_person_relation
# MAGIC where CPR_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC       and GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0

# COMMAND ----------

# MAGIC %sql
# MAGIC -- additional_customer_person_relation
# MAGIC select CPS_G_PERSON_ID, * 
# MAGIC except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC from dham_dwa_gsa_intg.cfpetra.additional_customer_person_relation
# MAGIC where CPS_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC       and GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0

# COMMAND ----------

# MAGIC %sql
# MAGIC --obtain person data for a customer (customer_person_relation, additional_customer_person_relation)
# MAGIC
# MAGIC -- select  per.PER_G_ID, per.PER_S_NAME,-- per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC --         cpr.CPR_G_PERSON_ID, cpr.CPR_G_CUSTOMER_ID, 
# MAGIC --         acpr.CPS_G_PERSON_ID, acpr.CPS_G_CUSTOMER_ID
# MAGIC -- --except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VA
# MAGIC
# MAGIC   select  cpr.CPR_G_CUSTOMER_ID as customerId,
# MAGIC   per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC   from dham_dwa_gsa_intg.cfpetra.person per
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.customer_person_relation cpr
# MAGIC   on per.PER_G_ID = cpr.CPR_G_PERSON_ID
# MAGIC   where per.GSA_ACTIVEFLAG = 1 and per.GSA_DELETEDFLAG = 0
# MAGIC         and cpr.GSA_ACTIVEFLAG = 1 and cpr.GSA_DELETEDFLAG = 0
# MAGIC         and cpr.CPR_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC
# MAGIC   union 
# MAGIC
# MAGIC   -- select CPS_G_PERSON_ID as personId
# MAGIC   select  acpr.CPS_G_CUSTOMER_ID as customerId,
# MAGIC   per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC   from dham_dwa_gsa_intg.cfpetra.person per
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.additional_customer_person_relation acpr
# MAGIC   on per.PER_G_ID = acpr.CPS_G_PERSON_ID
# MAGIC   where per.GSA_ACTIVEFLAG = 1 and per.GSA_DELETEDFLAG = 0
# MAGIC         and acpr.GSA_ACTIVEFLAG = 1 and acpr.GSA_DELETEDFLAG = 0
# MAGIC         and acpr.CPS_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC   select count(*)
# MAGIC   -- select ADI_S_COUNTRY, cus.*
# MAGIC   from dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC   join dham_dwa_gsa_intg.cfpetra.address_item addr
# MAGIC   on addr.ADI_S_PARENT_ID = cus.CST_S_ID_LOGICAL
# MAGIC   where addr.ADI_S_PARENT_TYPE = 'ICustomer'
# MAGIC         and addr.GSA_ACTIVEFLAG = 1 and addr.GSA_DELETEDFLAG = 0
# MAGIC         and cus.GSA_ACTIVEFLAG = 1 and cus.GSA_DELETEDFLAG = 0
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- customer and address_item
# MAGIC
# MAGIC -----------------------------------------------------------------------------
# MAGIC   --use of ADI_D_VALID_TO ? 2 entries for ADI_S_ID_PUBLIC='ADD-112353097'
# MAGIC -----------------------------------------------------------------------------
# MAGIC   select *
# MAGIC           -- cus.customer
# MAGIC   -- except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC   -- select ADI_S_COUNTRY, cus.*
# MAGIC   from dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.address_item addr
# MAGIC   on addr.ADI_S_PARENT_ID = cus.CST_S_ID_LOGICAL
# MAGIC   where addr.ADI_S_PARENT_TYPE = 'ICustomer'
# MAGIC
# MAGIC         and year(addr.ADI_D_VALID_TO) > 9000
# MAGIC         and CUS.CST_G_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC         and addr.GSA_ACTIVEFLAG = 1 and addr.GSA_DELETEDFLAG = 0
# MAGIC         and cus.GSA_ACTIVEFLAG = 1 and cus.GSA_DELETEDFLAG = 0

# COMMAND ----------

# MAGIC %sql
# MAGIC -- fund & customer
# MAGIC -- CUS.CST_G_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC
# MAGIC   select fun.*, cus.*
# MAGIC   from dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.funding fun
# MAGIC   on cus.CST_S_ID_LOGICAL = fun.FUN_S_CUSTOMER_LOGICAL_ID
# MAGIC   where CUS.CST_G_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC       and cus.GSA_ACTIVEFLAG = 1 and cus.GSA_DELETEDFLAG = 0
# MAGIC       and fun.GSA_ACTIVEFLAG = 1 and fun.GSA_DELETEDFLAG = 0
# MAGIC       
# MAGIC   -- select FUN_S_PERSON_GROUP, FUN_S_CUSTOMER_LOGICAL_ID, * 
# MAGIC   -- from dham_dwa_gsa_intg.cfpetra.funding   
# MAGIC   -- where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC   select  null, cpr.CPR_G_CUSTOMER_ID as customerId,
# MAGIC   per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC   from dham_dwa_gsa_intg.cfpetra.person per
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.customer_person_relation cpr
# MAGIC   on per.PER_G_ID = cpr.CPR_G_PERSON_ID
# MAGIC   where per.GSA_ACTIVEFLAG = 1 and per.GSA_DELETEDFLAG = 0
# MAGIC         and cpr.GSA_ACTIVEFLAG = 1 and cpr.GSA_DELETEDFLAG = 0
# MAGIC          and cpr.CPR_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC
# MAGIC   union
# MAGIC
# MAGIC   select  acpr.CPS_S_RELATIONTYPE, acpr.CPS_G_CUSTOMER_ID as customerId,
# MAGIC   per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC   from dham_dwa_gsa_intg.cfpetra.person per
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.additional_customer_person_relation acpr
# MAGIC   on per.PER_G_ID = acpr.CPS_G_PERSON_ID
# MAGIC   where per.GSA_ACTIVEFLAG = 1 and per.GSA_DELETEDFLAG = 0
# MAGIC         and acpr.GSA_ACTIVEFLAG = 1 and acpr.GSA_DELETEDFLAG = 0
# MAGIC         and acpr.CPS_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'

# COMMAND ----------

# MAGIC %md
# MAGIC ## all together

# COMMAND ----------

# MAGIC %sql
# MAGIC with valid_customer_data (
# MAGIC   select *
# MAGIC   -- except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC   from dham_dwa_gsa_intg.cfpetra.view_claimedproductwithvalidentities   
# MAGIC   where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0
# MAGIC         and ConnectionEntityType = 'ICustomer'
# MAGIC ),
# MAGIC customer_data (
# MAGIC   -- select *
# MAGIC   -- from dham_dwa_gsa_intg.cfpetra.customer
# MAGIC   -- where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0
# MAGIC
# MAGIC   select *
# MAGIC -----------------------------------------------------------------------------
# MAGIC --use of ADI_D_VALID_TO ? 2 entries for ADI_S_ID_PUBLIC='ADD-112353097'
# MAGIC -----------------------------------------------------------------------------
# MAGIC   -- except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) 
# MAGIC   -- select ADI_S_COUNTRY, cus.*
# MAGIC   from dham_dwa_gsa_intg.cfpetra.customer cus
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.address_item addr
# MAGIC   on addr.ADI_S_PARENT_ID = cus.CST_S_ID_LOGICAL
# MAGIC   where addr.ADI_S_PARENT_TYPE = 'ICustomer'
# MAGIC         -- and addr.ADI_D_VALID_TO = to_date('9999-12-31T23:59:59.999+00:00')
# MAGIC         -- and date_format(addr.ADI_D_VALID_TO, "yyyy-MM-dd'T'HH:mm:ss.SSSXXX") like '9999-12%'
# MAGIC         and year(addr.ADI_D_VALID_TO) > 9000 --valid entry for all versions
# MAGIC         and addr.GSA_ACTIVEFLAG = 1 and addr.GSA_DELETEDFLAG = 0
# MAGIC         and cus.GSA_ACTIVEFLAG = 1 and cus.GSA_DELETEDFLAG = 0
# MAGIC ),
# MAGIC person_data (
# MAGIC
# MAGIC   select  cpr.CPR_G_CUSTOMER_ID as customerId,
# MAGIC   per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC   from dham_dwa_gsa_intg.cfpetra.person per
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.customer_person_relation cpr
# MAGIC   on per.PER_G_ID = cpr.CPR_G_PERSON_ID
# MAGIC   where per.GSA_ACTIVEFLAG = 1 and per.GSA_DELETEDFLAG = 0
# MAGIC         and cpr.GSA_ACTIVEFLAG = 1 and cpr.GSA_DELETEDFLAG = 0
# MAGIC         -- and cpr.CPR_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC
# MAGIC   union 
# MAGIC
# MAGIC   select  acpr.CPS_G_CUSTOMER_ID as customerId,
# MAGIC   per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC   from dham_dwa_gsa_intg.cfpetra.person per
# MAGIC   left join dham_dwa_gsa_intg.cfpetra.additional_customer_person_relation acpr
# MAGIC   on per.PER_G_ID = acpr.CPS_G_PERSON_ID
# MAGIC   where per.GSA_ACTIVEFLAG = 1 and per.GSA_DELETEDFLAG = 0
# MAGIC         and acpr.GSA_ACTIVEFLAG = 1 and acpr.GSA_DELETEDFLAG = 0
# MAGIC         -- and acpr.CPS_G_CUSTOMER_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC
# MAGIC ),
# MAGIC funding_data (
# MAGIC   select * 
# MAGIC   from dham_dwa_gsa_intg.cfpetra.funding   
# MAGIC   where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0
# MAGIC )
# MAGIC
# MAGIC ----------------
# MAGIC
# MAGIC
# MAGIC -- select count(*)
# MAGIC select *
# MAGIC from valid_customer_data val
# MAGIC join customer_data cus
# MAGIC on cus.CST_G_ID = val.ConnectionEntityId
# MAGIC left join person_data per
# MAGIC on per.customerId = cus.CST_G_ID 
# MAGIC -- join funding_data fun
# MAGIC -- on cus.CST_G_ID = fun.FUN_S_CUSTOMER_ID
# MAGIC left join dham_dwa_gsa_intg.cfpetra.funding fun
# MAGIC on cus.CST_S_ID_LOGICAL = fun.FUN_S_CUSTOMER_LOGICAL_ID
# MAGIC where cus.CST_G_ID = '57d18e70-266a-4f6e-b891-aae570665676'
# MAGIC -- limit 10
# MAGIC ;
# MAGIC -- -- select count(*)
# MAGIC -- select   
# MAGIC --         val.PCL_G_ID,
# MAGIC --         -- fun.FUN_S_PERSON_GROUP,
# MAGIC --         cus.ADI_S_COUNTRY,
# MAGIC --         cus.CST_S_ID_PUBLIC, cus.CST_G_ID, cus.CST_S_NAME, cus.CST_S_ID_LOGICAL, cus.CST_S_CUSTOMER_TYPE, cus.CST_D_DATE_OF_BIRTH, cus.CST_S_ID_PUBLIC, cus.CST_S_ALLOCATION_ID,
# MAGIC --         per.PER_G_ID, per.PER_S_NAME, per.PER_N_PERSON_TYPE, per.PER_N_YEAR_OF_BIRTH, per.PER_S_NATIONALITY, per.PER_EXT_S_NATIONALITY2, per.PER_EXT_S_RESIDENCE_PERMIT, per.PER_S_MARITAL_STATUS, per.PER_EXT_S_IS_US_PERSON, per.PER_EXT_S_DOMICILIARY_COMPANY, per.PER_EXT_S_NOGA_CODE, per.PER_S_ID_PUBLIC
# MAGIC --         -- ,*
# MAGIC -- from valid_customer_data val
# MAGIC -- join customer_data cus
# MAGIC -- on cus.CST_G_ID = val.ConnectionEntityId
# MAGIC -- join person_data per
# MAGIC -- on per.CPR_G_CUSTOMER_ID = cus.CST_G_ID and per.CPS_G_CUSTOMER_ID = cus.CST_G_ID
# MAGIC -- -- join funding_data fun
# MAGIC -- -- on cus.CST_G_ID = fun.FUN_S_CUSTOMER_ID
# MAGIC -- where CST_S_NAME like '%Mangia%'
# MAGIC -- -- limit 10
# MAGIC -- ;

# COMMAND ----------

