# Databricks notebook source
# MAGIC %md
# MAGIC ###initial ones the same than market_value

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC PCL_S_ID_PUBLIC as INSTRUMENT_ID,
# MAGIC PCL_G_ID as INSTRUMENT_ALT_1_ID
# MAGIC ,*
# MAGIC from dham_dwa_gsa_intg.chpetra.product_completion
# MAGIC limit 2
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###product_completion_surcharge_deduction

# COMMAND ----------

# MAGIC %sql
# MAGIC select PCS_S_TYPE, PCS_N_SURCHARGE_DEDUCTION, 
# MAGIC * 
# MAGIC from dham_dwa_gsa_intg.cfpetra.product_completion_surcharge_deduction
# MAGIC limit 2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select PCD_N_CORRECTION, PCD_N_FORWARD, 
# MAGIC * 
# MAGIC from dham_dwa_gsa_intg.cfpetra.product_completion_interest_definition
# MAGIC limit 2
# MAGIC

# COMMAND ----------

