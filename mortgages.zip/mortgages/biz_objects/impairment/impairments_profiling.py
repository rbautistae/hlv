# Databricks notebook source
# MAGIC %sql
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.impairment_mortgages limit 10

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col

df_raw = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.impairment_mortgages"
)

# map definition: (original name, new name, spark type)
cols_map = [
    ("Stichtag", "stichtag", "date"),
    ("Position in aktueller Periode vorhanden", "position_in_aktueller_periode_vorhanden", "string"),
    ("Position in Vorperiode vorhanden", "position_in_vorperiode_vorhanden", "string"),
    ("Mandant", "mandant", "string"),
    ("Fun Nr.", "fun_nr", "string"),
    ("Vertrag", "vertrag", "long"),
    ("CUS Name", "cus_name", "string"),
    ("Impairments", "impairments", "double"),
    ("PRD", "prd", "string"),
]

# normalize possible blanks in original names
# (just in case blank in the end of csv)
current_cols = {c.strip(): c for c in df_raw.columns}

# select, rename and cast
select_exprs = []
for orig, new, typ in cols_map:
    if orig not in current_cols and orig.strip() in current_cols:
        orig = orig.strip()

    # spaces, points
    select_exprs.append(F.col(f"`{current_cols.get(orig, orig)}`").cast(typ).alias(new))

df = df_raw.select(*select_exprs)

# # (optional)verify
# df.printSchema()
# display(df.limit(10))

# Replace spaces and special characters in column names
df_clean = df.select([
    col(c).alias(
        c.replace(" ", "_").replace(".", "").replace("-", "_")
    ) for c in df.columns
])
df_clean


# COMMAND ----------

display(df_clean.describe())

# COMMAND ----------

# MAGIC %sql
# MAGIC describe dham_dwa_explorer_devl.raul_bautista.impairment_mortgages

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select count (distinct `Stichtag `) 1/51
# MAGIC -- select count (distinct `Mandant`) 3/51
# MAGIC -- select count (distinct `Fun Nr.`) --32/51
# MAGIC -- select count (distinct `Vertrag`) -- 51/51
# MAGIC -- select count (distinct `CUS Name`) -- 31/51
# MAGIC select count (distinct `PRD`) -- 51/51
# MAGIC from dham_dwa_explorer_devl.raul_bautista.impairment_mortgages

# COMMAND ----------

