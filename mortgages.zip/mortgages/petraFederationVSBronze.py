# Databricks notebook source
# MAGIC %md
# MAGIC # PETRA: Federation vs DIH Bronze comparison
# MAGIC ## Characteristics
# MAGIC 1. Schema comparison
# MAGIC 2. Content comparison

# COMMAND ----------

# MAGIC %md
# MAGIC ### Petra federation objects (fed_petra_devl.dbo)

# COMMAND ----------

# %sql 
# -- describe fed_petra_devl.dbo.view_amortisation;
# describe fed_petra_devl.dbo.additional_collateral_person;


# COMMAND ----------

# %sql 
# -- describe dham_dwa_gsa_devl.cfpetra.view_amortisation;
# describe dham_dwa_gsa_devl.cfpetra.additional_collateral_person;


# COMMAND ----------

# MAGIC %md
# MAGIC ### DIH Bronze objects (dham_dwa_gsa_devl.cfpetra)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Schema differences (only differences are conversion 'varchar(2147483647)' -> 'varchar(4096)')

# COMMAND ----------

def get_schema_common_fields(table1: str, table2: str):
    """
    Retrieves the common fields between two tables in Databricks.

    Parameters:
        table1 (str): Name of the first table in the format 'database.schema.table'
        table2 (str): Name of the second table in the format 'database.schema.table'

    Returns:
        DataFrame containing the common columns in both tables.
    """
    df1 = spark.sql(f"DESCRIBE {table1}").drop("comment")
    df2 = spark.sql(f"DESCRIBE {table2}").drop("comment")
    set1 = set(df1.collect())
    set2 = set(df2.collect())
    fields_in_both = set1 & set2
    common_df = spark.createDataFrame(fields_in_both, ["column_name", "data_type"])

    return common_df

def get_schema_diff_fields(table1: str, table2: str):
    """
    Retrieves the diff fields between two tables in Databricks.

    Parameters:
        table1 (str): Name of the first table in the format 'database.schema.table'
        table2 (str): Name of the second table in the format 'database.schema.table'

    Returns:
        DataFrame containing the diff columns in both tables.
    """
    df1 = spark.sql(f"DESCRIBE {table1}")#.drop("comment")
    df2 = spark.sql(f"DESCRIBE {table2}")#.drop("comment")
    
    # ----------------------------
    # # consider varchar length
    # set1 = set(df1.collect())
    # set2 = set(df2.collect())
    # diff_fields = set1 - set2
    # ----------------------------
    # do not consider varchar length ?!
    diff_fields = set(df1.dtypes) ^ set(df2.dtypes)
    # ----------------------------

    return diff_fields

# COMMAND ----------

tables = [
    "view_amortisation",
    "view_auszahlung",
    "view_beanspruchung",
    "view_claimedproductwithvalidentities",
    "view_tilgung_umbuchung",
    "view_umbuchung",

    "gmer",
    "income_outgo",
    "interest_position",
    "lsv_debit_authorisation",
    "lsv_identification",
    "mailing_instruction",
    "pension_fund",
    "person",
    "product_completion",
    "product_completion_interest_definition",
    "product_completion_surcharge_deduction",
    "real_estate",
    "real_security",
    "redemption_position",

    "contract_definition_note",
    "credit_check",
    "credit_position",
    "customer",
    "customer_person_relation",
    "fee_position",
    "funding",
    "funding_additional_collateral_person_relation",
    "funding_third_real_estate_housing_cost_relation",
    "funding_third_real_estate_relation",

    "appraisement",
    "archive_from_to",
    "beneficialowner_relation",
    "capital_resource",
    "capital_voucher",
    "claim_position",
    "claim_voucher",
    "contract_definition",

    "additional_collateral_person",
    "additional_collateral_real_estate",
    "additional_customer_person_relation",
    "address_item",
    "anti_money_laundering"
]


# COMMAND ----------

diff_set = get_schema_diff_fields(f"fed_petra_devl.dbo.{tables[0]}", f"dham_dwa_gsa_devl.cfpetra.{tables[0]}")

for table in tables[1:]:
    diff_set.update(get_schema_diff_fields(f"fed_petra_devl.dbo.{table}", f"dham_dwa_gsa_devl.cfpetra.{table}"))

# print("Schema differences found:" if diff_set else "No schema differences found", diff_set)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC #### Content differences

# COMMAND ----------

# %sql
# select count(*)
# from fed_petra_devl.dbo.anti_money_laundering


# COMMAND ----------

# %sql
# select count(*) 
# from dham_dwa_gsa_devl.cfpetra.anti_money_laundering where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;


# COMMAND ----------

# %sql
# with fed_anti_money_laundering as (
#     select *
#     from fed_petra_devl.dbo.anti_money_laundering 
# )
# , bronze_anti_money_laundering (
#     select * except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG, GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS)
#     from dham_dwa_gsa_devl.cfpetra.anti_money_laundering
# )

# select *
# from bronze_anti_money_laundering
# except all 
# select *
# from fed_anti_money_laundering
# ;

# COMMAND ----------

from pyspark.sql import SparkSession

def compare_tables_data(table1_name, table2_name):
    """
    Compares the content of two tables in a Spark session.

    Parameters:
    table1_name (str): Name of the first table.
    table2_name (str): Name of the second table.

    Returns:
    bool: True if tables contain the same data, False otherwise.
    """
    
    dfFederation = spark.table(table1_name)
    dfBronze = spark.sql(f"SELECT * except (JRU_ID_JOBRUN_INS, JRU_ID_JOBRUN_UPD, RCN_ID_RECONCILIATION, DWH_ROWID, GSA_ACTIVEFLAG,GSA_DELETEDFLAG, GSA_VALIDFROM_TS, GSA_VALIDTO_TS) FROM {table2_name} WHERE GSA_ACTIVEFLAG = 1 AND GSA_DELETEDFLAG = 0")

    if dfFederation.count() != dfBronze.count():
        print("Row counts are different.")
        return False
    
    dfFederation_not_in_dfBronze = dfFederation.exceptAll(dfBronze)
    dfBronze_not_in_dfFederation = dfBronze.exceptAll(dfFederation)
    
    if dfFederation_not_in_dfBronze.count() > 0 or dfBronze_not_in_dfFederation.count() > 0:
        print("Data mismatch found.")
        return False

    return True

# COMMAND ----------

sameData = True
for table in tables:
    sameData = sameData and compare_tables_data(f"fed_petra_devl.dbo.{table}", f"dham_dwa_gsa_devl.cfpetra.{table}")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Result

# COMMAND ----------

if diff_set:
    print(f"Schema differences found:",  {diff_set})
    raise Exception("Schema differences found.")
else:
    print("No schema differences found")

if sameData:
    print("Tables contain the same data.")
else:
    raise Exception("Tables are different (REVIEW)")
    print("***Tables are different! (REVIEW)***")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Historization example

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from dham_dwa_gsa_devl.cfpetra.anti_money_laundering 
# MAGIC --where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0 
# MAGIC where AML_G_ID = '03a4368b-a402-46bd-bed4-3d42c609cea2'
# MAGIC --and GSA_VALIDFROM_TS < '2025-02-05'
# MAGIC --and '2025-02-01' < GSA_VALIDTO_TS 
# MAGIC limit 2;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from dham_dwa_gsa_devl.cfpetra.customer
# MAGIC where CST_S_ID_PUBLIC in ('CUS-139885158')
# MAGIC limit 2;

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from fed_petra_devl.dbo.customer
# MAGIC where CST_S_ID_PUBLIC  like '%139885158%'
# MAGIC limit 2;

# COMMAND ----------

