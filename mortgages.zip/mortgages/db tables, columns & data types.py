# Databricks notebook source
# MAGIC %sql
# MAGIC select * from fed_petra_devl.dbo.sysssislog limit 100;

# COMMAND ----------

from pyspark.sql import SparkSession

database_name = "fed_petra_devl.dbo"

tables_df = spark.sql(f"SHOW TABLES IN {database_name}")
# tables_df.show()

tables_info = []

for row in tables_df.collect():
    table_name = row["tableName"]
    columns_df = spark.sql(f"DESCRIBE TABLE EXTENDED {database_name}.{table_name}")
    
    for column in columns_df.collect():
        if column["col_name"] != "" and column["data_type"] != "": 
            tables_info.append({
            #    "database": database_name,
                "table_name": table_name,
                "column_name": column["col_name"],
                "data_type": column["data_type"],
                "comment": column["comment"] if "comment" in column else None,
                "is_nullable": "Yes" if "null" in column["data_type"].lower() else "No",
                # "is_partitioned": is_partitioned,
                # "partitions": ", ".join(partitions),
                "column_position": columns_df.collect().index(column) + 1
            })

schema_df = spark.createDataFrame(tables_info)

# schema_df.show(truncate=False)
schema_df.count()

display(schema_df)


# COMMAND ----------

