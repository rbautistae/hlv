# Databricks notebook source
# MAGIC %sql
# MAGIC --use catalog 'fed_petra_devl';
# MAGIC --select count(*) from fed_petra_devl.dbo.sysssislog;
# MAGIC -- select * from fed_petra_devl.dbo.sysssislog limit 10;
# MAGIC select * from fed_petra_devl.dbo.funding limit 10;
# MAGIC

# COMMAND ----------

sql
select *
from fed_petra_devl.dbo.sysssislog
order by source

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW dham_dwa_explorer_devl.raul_bautista.vw_petra_data AS
# MAGIC
# MAGIC   with petra_data as (
# MAGIC       select * from fed_petra_devl.dbo.sysssislog
# MAGIC   )
# MAGIC
# MAGIC   select *
# MAGIC   from petra_data
# MAGIC   order by source
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE MATERIALIZED VIEW dham_dwa_explorer_devl.raul_bautista.mvw_petra_data AS
# MAGIC -- COMMENT 'blabla'
# MAGIC -- SCHEDULE CRON '0 0 0 * * ? *'
# MAGIC
# MAGIC   with petra_data as (
# MAGIC       select * from fed_petra_devl.dbo.sysssislog
# MAGIC   )
# MAGIC
# MAGIC   select *
# MAGIC   from petra_data
# MAGIC   order by source
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE MATERIALIZED VIEW `dham_dwa_explorer_devl`.`raul_bautista`.`mvw_petra_data` AS SELECT * FROM `fed_petra_devl`.`dbo`.`sysssislog`;
# MAGIC

# COMMAND ----------

