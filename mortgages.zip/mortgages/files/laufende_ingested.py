# Databricks notebook source
# MAGIC %sql
# MAGIC select 'hast (1 more ingest than rest)' as table_name, count(*) as total
# MAGIC from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hast
# MAGIC union all
# MAGIC select 'hvel', count(*)
# MAGIC from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvel
# MAGIC union all
# MAGIC select 'hvkl', count(*)
# MAGIC from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvkl
# MAGIC union all
# MAGIC select 'hvnl', count(*)
# MAGIC from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvnl
# MAGIC union all
# MAGIC select 'hvpk', count(*)
# MAGIC from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvpk
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- laufende files 
# MAGIC --hast
# MAGIC select count(*) from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hast;
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hast limit 10;
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hast_err where JRU_ID_JOBRUN_INS_ERR = 18587 limit 10;
# MAGIC -- select distinct JRU_ID_JOBRUN_INS_ERR from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hast_err;
# MAGIC -- --hvel
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvel limit 10;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvel_err 
# MAGIC -- select distinct JRU_ID_JOBRUN_INS_ERR from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvel_err 
# MAGIC
# MAGIC -- --hvkl
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvkl ;
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvkl_err 
# MAGIC -- select distinct JRU_ID_JOBRUN_INS_ERR from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvkl_err 
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvkl_err where JRU_ID_JOBRUN_INS_ERR = 18758 limit 10;
# MAGIC
# MAGIC -- --hvnl
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvnl limit 10;
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvnl_err 
# MAGIC -- --hvpk
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvpk limit 10;
# MAGIC -- select * from dham_dwa_gsa_devl.chpetra.petra_portfolio_position_hvpk_err 
# MAGIC

# COMMAND ----------

