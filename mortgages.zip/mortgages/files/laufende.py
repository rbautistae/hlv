# Databricks notebook source
# MAGIC %sql
# MAGIC --overview
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.20260127_laufende_hvkl
# MAGIC limit 10
# MAGIC ;

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.20260127_laufende_hvkl"
)
display(df.describe())

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dham_dwa_explorer_devl.raul_bautista.20260113_laufende_hvkl

# COMMAND ----------

# MAGIC %md
# MAGIC ####With null values: amortisiert, zins, auftragsnummer

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dham_dwa_explorer_devl.raul_bautista.20260127_laufende_hvkl
# MAGIC -- where amortisiert is null
# MAGIC -- where zins is null
# MAGIC where auftragsnummer is null

# COMMAND ----------

product_count = df.select("produkt_id").distinct().count()
display(product_count)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Karine pk proposal: Mandant_id / Produkt_ID / CST_S_ID_PUBLIC / Referenzdatum

# COMMAND ----------

# MAGIC %sql
# MAGIC select mandant_id, produkt_id, kunden_id, referenzdatum, count(*) as howMany
# MAGIC from dham_dwa_explorer_devl.raul_bautista.20260127_laufende_hvkl
# MAGIC group by mandant_id, produkt_id, kunden_id, referenzdatum
# MAGIC having howMany > 1

# COMMAND ----------

