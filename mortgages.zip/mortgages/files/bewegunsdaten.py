# Databricks notebook source
# MAGIC %sql
# MAGIC --overview
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten
# MAGIC limit 10
# MAGIC ;

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten"
)
display(df.describe())

# COMMAND ----------

# MAGIC %md
# MAGIC ###Karine key proposal (not possible, can be null: unique_id_einzahlung_credit_position, unique_id_tilgung_redemption_position)

# COMMAND ----------

# MAGIC %sql
# MAGIC select as_of_date, unique_id_forderung_claim_position --,unique_id_einzahlung_credit_position, unique_id_tilgung_redemption_position
# MAGIC , count(*) as howMany
# MAGIC from dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten           
# MAGIC group by as_of_date, unique_id_forderung_claim_position --,unique_id_einzahlung_credit_position, unique_id_tilgung_redemption_position
# MAGIC having howMany > 2
# MAGIC --order by as_of_date, unique_id_forderung_claim_position, --unique_id_einzahlung_credit_position, unique_id_tilgung_redemption_position

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct substring_index(public_id_position, '-', 1)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### when public_id_position='RED%' then unique_id_einzahlung_credit_position and unique_id_tilgung_redemption_position are informed

# COMMAND ----------

# MAGIC %sql
# MAGIC select public_id_position, unique_id_forderung_claim_position, unique_id_einzahlung_credit_position, unique_id_tilgung_redemption_position
# MAGIC from dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten
# MAGIC where public_id_position like 'RED%'
# MAGIC and (unique_id_einzahlung_credit_position is null or unique_id_tilgung_redemption_position is null)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten
# MAGIC where unique_id_forderung_claim_position is null
# MAGIC --where unique_id_einzahlung_credit_position is null
# MAGIC --where unique_id_tilgung_redemption_position is null
# MAGIC

# COMMAND ----------

unique_id_einzahlung_credit_position_count = df.select("unique_id_einzahlung_credit_position").distinct().count()
display(unique_id_einzahlung_credit_position_count)


# COMMAND ----------

# MAGIC %md
# MAGIC ### key proposal (as_of_date, unique_id_forderung_claim_position, public_id_position)[](url)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select as_of_date, unique_id_forderung_claim_position, public_id_position
# MAGIC , count(*) as howMany
# MAGIC from dham_dwa_explorer_devl.raul_bautista.20260112_bewegungsdaten           
# MAGIC group by as_of_date, unique_id_forderung_claim_position, public_id_position
# MAGIC having howMany > 1  

# COMMAND ----------

