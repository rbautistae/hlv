# Databricks notebook source
# MAGIC %sql
# MAGIC --overview
# MAGIC select * from dham_dwa_explorer_devl.raul_bautista.helvetia_existing_products_20260215
# MAGIC limit 10
# MAGIC ;

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.helvetia_existing_products_20260215"
)
display(df.describe())

# COMMAND ----------

df = spark.table(
    "dham_dwa_explorer_devl.raul_bautista.helvetia_existing_products_20260214"
)
display(df.describe())

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dham_dwa_explorer_devl.raul_bautista.helvetia_existing_products_20260215

# COMMAND ----------

# MAGIC %md
# MAGIC #### Karine pk proposal: (FUN_S_ID_PUBLIC, PCL_S_ID_PUBLIC, PCL_G_ID, ReferenceDate)

# COMMAND ----------

# MAGIC %sql
# MAGIC select FUN_S_ID_PUBLIC, PCL_S_ID_PUBLIC, PCL_G_ID, ReferenceDate, count(*) as howMany
# MAGIC from dham_dwa_explorer_devl.raul_bautista.helvetia_existing_products_20260215
# MAGIC group by FUN_S_ID_PUBLIC, PCL_S_ID_PUBLIC, PCL_G_ID, ReferenceDate
# MAGIC having howMany > 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Timestamp format valid for databricks ? (yes)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT to_timestamp('2/15/2026 12:00:00 AM', 'M/d/yyyy h:mm:ss a') AS parsed_ts;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT to_timestamp('2/15/2026 12:00:00 PM', 'M/d/yyyy h:mm:ss a') AS parsed_ts;

# COMMAND ----------

