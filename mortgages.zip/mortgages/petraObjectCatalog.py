# Databricks notebook source
# MAGIC %md
# MAGIC # PETRA: Object catalog
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Petra federation objects (fed_petra_devl.dbo)

# COMMAND ----------

# MAGIC %sql 
# MAGIC --5th block
# MAGIC -- select count(*) from fed_petra_devl.dbo.view_amortisation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.view_auszahlung;
# MAGIC -- select count(*) from fed_petra_devl.dbo.view_beanspruchung;
# MAGIC select count(*) from fed_petra_devl.dbo.view_claimedproductwithvalidentities;
# MAGIC -- select count(*) from fed_petra_devl.dbo.view_tilgung_umbuchung;
# MAGIC -- select count(*) from fed_petra_devl.dbo.view_umbuchung;
# MAGIC
# MAGIC -- --4th block
# MAGIC -- select count(*) from fed_petra_devl.dbo.gmer;
# MAGIC -- select count(*) from fed_petra_devl.dbo.income_outgo;
# MAGIC -- select count(*) from fed_petra_devl.dbo.interest_position;
# MAGIC -- select count(*) from fed_petra_devl.dbo.lsv_debit_authorisation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.lsv_identification;
# MAGIC -- select count(*) from fed_petra_devl.dbo.mailing_instruction;
# MAGIC -- select count(*) from fed_petra_devl.dbo.pension_fund;
# MAGIC -- select count(*) from fed_petra_devl.dbo.person;
# MAGIC -- select count(*) from fed_petra_devl.dbo.product_completion;
# MAGIC -- select count(*) from fed_petra_devl.dbo.product_completion_interest_definition;
# MAGIC -- select count(*) from fed_petra_devl.dbo.product_completion_surcharge_deduction;
# MAGIC -- select count(*) from fed_petra_devl.dbo.real_estate;
# MAGIC -- select count(*) from fed_petra_devl.dbo.real_security;
# MAGIC -- select count(*) from fed_petra_devl.dbo.redemption_position;
# MAGIC
# MAGIC -- --3rd block
# MAGIC -- select count(*) from fed_petra_devl.dbo.contract_definition_note;
# MAGIC -- select count(*) from fed_petra_devl.dbo.credit_check;
# MAGIC -- select count(*) from fed_petra_devl.dbo.credit_position;
# MAGIC -- select count(*) from fed_petra_devl.dbo.customer;
# MAGIC -- select count(*) from fed_petra_devl.dbo.customer_person_relation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.fee_position;
# MAGIC -- select count(*) from fed_petra_devl.dbo.funding;
# MAGIC -- select count(*) from fed_petra_devl.dbo.funding_additional_collateral_person_relation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.funding_third_real_estate_housing_cost_relation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.funding_third_real_estate_relation;
# MAGIC
# MAGIC -- --2nd block
# MAGIC -- select count(*) from fed_petra_devl.dbo.appraisement;
# MAGIC -- select count(*) from fed_petra_devl.dbo.archive_from_to;
# MAGIC -- select count(*) from fed_petra_devl.dbo.beneficialowner_relation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.capital_resource;
# MAGIC -- select count(*) from fed_petra_devl.dbo.capital_voucher;
# MAGIC -- select count(*) from fed_petra_devl.dbo.claim_position;
# MAGIC -- select count(*) from fed_petra_devl.dbo.claim_voucher;
# MAGIC -- select count(*) from fed_petra_devl.dbo.contract_definition;
# MAGIC
# MAGIC -- --1st block
# MAGIC -- select count(*) from fed_petra_devl.dbo.additional_collateral_person;
# MAGIC -- select count(*) from fed_petra_devl.dbo.additional_collateral_real_estate;
# MAGIC -- select count(*) from fed_petra_devl.dbo.additional_customer_person_relation;
# MAGIC -- select count(*) from fed_petra_devl.dbo.address_item;
# MAGIC -- select count(*) from fed_petra_devl.dbo.anti_money_laundering;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### DIH Bronze objects (dham_dwa_gsa_devl.cfpetra)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- --5th block
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.view_amortisation;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.view_auszahlung;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.view_beanspruchung;
# MAGIC select count(*) from dham_dwa_gsa_devl.cfpetra.view_claimedproductwithvalidentities;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.view_tilgung_umbuchung;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.view_umbuchung;
# MAGIC
# MAGIC -- --4th block
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.gmer where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.income_outgo where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.interest_position where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.lsv_debit_authorisation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.lsv_identification where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.mailing_instruction where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.pension_fund where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.person where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.product_completion where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.product_completion_interest_definition where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.product_completion_surcharge_deduction where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.real_estate where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.real_security where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.redemption_position where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC
# MAGIC -- --3rd block
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.contract_definition_note where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.credit_check where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.credit_position where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.customer where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.customer_person_relation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.fee_position where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.funding where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.funding_additional_collateral_person_relation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.funding_third_real_estate_housing_cost_relation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.funding_third_real_estate_relation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC
# MAGIC -- --2nd block
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.appraisement where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.archive_from_to where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.beneficialowner_relation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.capital_resource where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.capital_voucher where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.claim_position where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.claim_voucher where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.contract_definition where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC
# MAGIC -- --1st block
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.additional_collateral_person where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.additional_collateral_real_estate where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.additional_customer_person_relation where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.address_item where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC -- select count(*) from dham_dwa_gsa_devl.cfpetra.anti_money_laundering where GSA_ACTIVEFLAG = 1 and GSA_DELETEDFLAG = 0;
# MAGIC