# Databricks notebook source
# MAGIC %md
# MAGIC # Column masking example
# MAGIC
# MAGIC ## Open points
# MAGIC - Databricks Runtime 15.4 LTS or above: https://docs.databricks.com/aws/en/tables/row-and-column-filters

# COMMAND ----------

# MAGIC %md
# MAGIC ## Clean objects

# COMMAND ----------

# MAGIC %sql
# MAGIC drop function if exists dham_dwa_explorer_devl.raul_bautista.generic_redact;
# MAGIC drop function if exists dham_dwa_explorer_devl.raul_bautista.generic_redact_ts;
# MAGIC drop table if exists dham_dwa_explorer_devl.raul_bautista.test_mask;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Function creation

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace function dham_dwa_explorer_devl.raul_bautista.generic_redact(field string) returns string
# MAGIC   return case when field is null then null else 'REDACTED' end;
# MAGIC create or replace function dham_dwa_explorer_devl.raul_bautista.generic_redact_ts(field timestamp) returns string
# MAGIC   return case when field is null then null else 'XX.XX.XXXX' end;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table creation

# COMMAND ----------

# MAGIC %md
# MAGIC ### option 1

# COMMAND ----------

# %sql 
# create table if not exists dham_dwa_explorer_devl.raul_bautista.test_mask(
#   name string, 
#   birth_date timestamp mask dham_dwa_explorer_devl.raul_bautista.generic_redact_ts, 
#   value string mask dham_dwa_explorer_devl.raul_bautista.generic_redact);

# COMMAND ----------

# MAGIC %md
# MAGIC ### option 2

# COMMAND ----------

# MAGIC %sql
# MAGIC --alternative
# MAGIC create table if not exists dham_dwa_explorer_devl.raul_bautista.test_mask(
# MAGIC   name string, 
# MAGIC   birth_date timestamp, 
# MAGIC   value string);
# MAGIC
# MAGIC alter table dham_dwa_explorer_devl.raul_bautista.test_mask alter column birth_date set mask dham_dwa_explorer_devl.raul_bautista.generic_redact_ts;
# MAGIC alter table dham_dwa_explorer_devl.raul_bautista.test_mask alter column value set mask dham_dwa_explorer_devl.raul_bautista.generic_redact;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data insertion

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into dham_dwa_explorer_devl.raul_bautista.test_mask values('James', current_timestamp(), 'value1');
# MAGIC insert into dham_dwa_explorer_devl.raul_bautista.test_mask values('Pep', '1968-05-21T00:00:00.000+00:00', 'value2');
# MAGIC insert into dham_dwa_explorer_devl.raul_bautista.test_mask values('John', null, 'value3');
# MAGIC insert into dham_dwa_explorer_devl.raul_bautista.test_mask values('Skyler', '1998-05-21T00:00:00.000+00:00', null);

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from dham_dwa_explorer_devl.raul_bautista.test_mask
# MAGIC limit 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT PER_D_DATE_OF_BIRTH, * FROM dham_dwa_gsa_devl.cfpetra.person
# MAGIC limit 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT ADI_D_DATE_OF_BIRTH, * FROM dham_dwa_gsa_devl.cfpetra.address_item
# MAGIC -- where ADI_D_DATE_OF_BIRTH is not null;
# MAGIC limit 10;

# COMMAND ----------

