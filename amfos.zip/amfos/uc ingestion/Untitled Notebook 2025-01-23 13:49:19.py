# Databricks notebook source
from pyspark.sql import functions as F
col = F.lit(None).cast("boolean")
print(col)


# COMMAND ----------

print(type(col))

# COMMAND ----------


data = [(1, "Alice"), (2, "Bob"), (3, "Charlie")]
df = spark.createDataFrame(data, ["id", "name"])
df_with_corrupt_column = df.withColumn("_corrupt_record", F.lit(True))
df_with_corrupt_column.show()


# COMMAND ----------

# df_not_null_records = df_with_corrupt_column.filter(F.col("_corrupt_record").isNotNull())
df_not_null_records = df_with_corrupt_column.where("_corrupt_record = False")
df_not_null_records.show()


# COMMAND ----------

    df_with_corrupt_column.schema

# COMMAND ----------

if df_not_null_records.head():
    print(1)
else:
    print(2)

# COMMAND ----------

print(type(lala))

# COMMAND ----------

