# Databricks notebook source
# MAGIC %md
# MAGIC ### (No serverless cluster if caching)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adaptation CSV corrupt_record mechanism to a reading uc table scenario (not a file)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import StringType, StructField, StructType
import copy    

def validate_and_ingest(srcTable, dstTable):
    """
    Validates and ingests data from srcTable into dstTable while ensuring tabla2 conforms to srcTable's schema.

    Parameters
    ----------
    srcTable: str
        The source table name in Databricks, which defines the correct schema.
    dstTable: str
        The target table name in Databricks to receive the data.

    Returns
    -------
    dfValid : DataFrame
        DataFrame containing rows from srcTable that match dstTable's schema.
    dfInvalid : DataFrame
        DataFrame containing rows that do not conform to dstTable's schema.
    """
    # Load the schema of source
    source_df = spark.read.table(srcTable)
    source_schema = source_df.schema

    # if dst table does not exists create it
    try:
        target_df = spark.read.table(dstTable)
        target_schema = target_df.schema
    except:
        # if destination does not exist, create an empty DataFrame with source_schema
        # source_df.write.format("delta").mode("overwrite").saveAsTable(dstTable)
        target_schema = source_schema
    print(f"target_schema: {target_schema}")
    
  
    # Check if source schema and target schema are the same
    if source_schema == target_schema:
        # Add a "_corrupt_record" column with NULL for all rows
        source_df = source_df.withColumn("_corrupt_record", F.lit(None).cast("boolean"))
    else:
        # Add a "_corrupt_record" column with True for all rows
        source_df = source_df.withColumn("_corrupt_record", F.lit(True))

        # Overwrite destination table with source data if schemas match
        # source_df.drop("_corrupt_record").write.format("delta").mode("overwrite").saveAsTable(dstTable)
        print(f"Data in {dstTable} overwritten with data from {srcTable}.")

    # Separate valid and invalid rows based on conformity to target schema
    dfValid = source_df.where("_corrupt_record is null").drop("_corrupt_record")
    dfInvalid = source_df.where("_corrupt_record is not null").drop("_corrupt_record")

    return dfValid, dfInvalid


# COMMAND ----------

# Databricks table names
srcTableName = "dham_dwa_explorer_devl.raul_bautista.uc_source"
dstTableName = "dham_dwa_explorer_devl.raul_bautista.uc_destination"

# Validate and ingest data from srcTableName into dstTableName
dfValid, dfInvalid = validate_and_ingest(srcTableName, dstTableName)

# Display results
print("Valid Data:")
dfValid.show()

print("Invalid Data:")
dfInvalid.show()



# COMMAND ----------

# def table_exists(table_name):
#     """
#     Checks if a table exists in the current database or catalog.

#     Parameters
#     ----------
#     table_name : str
#         The full name of the table (e.g., "database_name.table_name").
#     spark : SparkSession
#         The active Spark session.

#     Returns
#     -------
#     bool
#         True if the table exists, False otherwise.
#     """
#     try:
#         spark.catalog.getTable(table_name)
#         return True
#     except Exception as e:
#         # Table does not exist if an exception is raised
#         if "Table or view not found" in str(e):
#             return False
#         else:
#             raise e  # Re-raise unexpected exceptions

# exists = table_exists(dst_table_name)
# if exists:
#     print(f"Table '{dst_table_name}' exists.")
# else:
#     print(f"Table '{dst_table_name}' does not exist.")

# COMMAND ----------

# %sql 
# --drop table if exists dham_dwa_explorer_devl.raul_bautista.uc_source;
# --drop table if exists dham_dwa_explorer_devl.raul_bautista.uc_destination;


# COMMAND ----------

