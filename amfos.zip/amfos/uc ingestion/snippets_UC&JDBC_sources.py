# Databricks notebook source
# MAGIC %md
# MAGIC ## UC cfg

# COMMAND ----------

    
# def _fReadUC(catalog, schema, tableView):
#     """
#     Read data from a source table or view

#     :param catalog: Catalog of the source table
#     :param schema: Schema of the source table
#     :param tableView: Name of the source table or view
#     """
#     try:
#         src_table = f"{catalog}.{schema}.{tableView}"
#         print(f"Reading data from {src_table}...")
#         df = spark.read.table(src_table)
        
#         print(f"Data read successfully completed from {src_table}.")
#         return df
#     except Exception as e:
#         print(f"Error during ingestion: {e}")

# COMMAND ----------

# # table
# ucOptions = {
#     "srcCatalog": "fed_petra_devl",
#     "srcSchema": "dbo",
#     "srcTableView": "sysssislog"
# }
# # view
# # ucOptions = {
# #     "srcCatalog": "dham_dwa_explorer_devl",
# #     "srcSchema": "raul_bautista",
# #     "srcTableView": "vw_petra_data_test"
# # }

# dfData = _fReadUC(ucOptions["srcCatalog"], ucOptions["srcSchema"], ucOptions["srcTableView"])
# dfData

# COMMAND ----------

# MAGIC %md
# MAGIC ## JDBC cfg

# COMMAND ----------

dfDataEmpty = None

# COMMAND ----------

# def _generateSAP_JDBC_URL(host, port, autocommit=True, encrypt=False, validateCertificate=True):
#     """
#     Generate a SAP JDBC connection URL.
#     https://help.sap.com/docs/SAP_HANA_CLIENT/f1b440ded6144a54ada97ff95dac7adf/109397c2206a4ab2a5386d494f4cf75e.html

#     :param host: The database host  
#     :param port: The database port
#     :param autocommit: Optional, whether to enable autocommit (default: True)
#     :param encrypt: Optional, whether to enable encryption (default: False)
#     :param validateCertificate: Optional, whether to validate certificates (default: True)
#     :return: A string representing the JDBC connection URL
#     """
#     autocommitStr = str(autocommit).lower()
#     encryptStr = str(encrypt).lower()
#     validateCertificateStr = str(validateCertificate).lower()

#     # e.g.: "jdbc:sap://vmdbh43s0helv.sap.az.helvetia.corp:34353/?autocommit=false&encrypt=true&validateCertificate=false"
#     jdbcURL = f"jdbc:sap://{host}:{port}/?autoCommit={autocommitStr}&encrypt={encryptStr}&validateCertificate={validateCertificateStr}"
#     return jdbcURL



# COMMAND ----------

# jdbcUrl = _generateSAP_JDBC_URL("vmdbh43s0helv.sap.az.helvetia.corp", "34353")
# jdbcUrl

# COMMAND ----------

# jdbcUrl = _generateSAP_JDBC_URL("vmdbh43s0helv.sap.az.helvetia.corp", "34353", False, True, False)
# jdbcUrl

# COMMAND ----------

# MAGIC %md
# MAGIC ## CSV read, control corrupted data
# MAGIC - Tests regarding error control in csv
# MAGIC - https://spark.apache.org/docs/3.5.1/sql-data-sources-csv.html#:~:text=To%20keep%20corrupt%20records%2C%20an,a%20corrupted%20record%20to%20CSV.
# MAGIC - https://www.geeksforgeeks.org/identify-corrupted-records-in-a-dataset-using-pyspark/
# MAGIC - https://medium.com/@sasidharan-r/how-to-handle-corrupt-or-bad-record-in-apache-spark-custom-logic-pyspark-aws-430ddec9bb41

# COMMAND ----------

csvFileOk = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/testOk.csv"

# read original schema infering
dfInfering = spark.read.format("csv") \
      .option("header", "true") \
      .option("inferSchema", "true") \
      .load(csvFileOk)
dfInfering.show()
dfInfering.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from pyspark.sql import functions as F

# add corrupted record mechanism field
corrupted_field = StructField("_corrupt_record", StringType(), True)
okSchemaWithCorruptedFld = StructType(dfInfering.schema.fields + [corrupted_field])

# COMMAND ----------

csvFileKO1 = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/testKO1.csv"
dfKO1 = spark.read.format("csv") \
      .option("mode", "PERMISSIVE") \
      .schema(okSchemaWithCorruptedFld) \
      .option("header", "true") \
      .option("rescuedDataColumn", "_rescued_data") \
      .load(csvFileKO1)
display(dfKO1)
dfKO1.printSchema()


# COMMAND ----------

csvFileKO2 = "/Volumes/dham_dwa_explorer_devl/volumes/explorer_volume/rbe/amis_interfaces/testKO2.csv"
dfKO2 = spark.read.format("csv") \
      .option("mode", "PERMISSIVE") \
      .schema(okSchemaWithCorruptedFld) \
      .option("header", "true") \
      .option("rescuedDataColumn", "_rescued_data") \
      .load(csvFileKO2)
# spark.conf.set("spark.databricks.sql.rescuedDataColumn.filePath.enabled", "false")
display(dfKO2)
dfKO2.printSchema()
# _rescued_data contains recovered data out of schema used for read

# COMMAND ----------

# MAGIC %md
# MAGIC ## dfValid, dfInvalid from original dataframe

# COMMAND ----------

print('_rescued_data' in dfKO1.columns)
# Caching is needed for corrupt records to be kept.
dfKO1.cache()
dfKO2.cache()

# valid rows
dfValidKO1 = dfKO1.where("(_rescued_data IS NULL or _rescued_data = '{}') and _corrupt_record is NULL").drop("_rescued_data", "_corrupt_record")
dfValidKO1.show()
# invalid rows
dfInvalidKO1 = (
            dfKO1.alias("in")
            .where("(_rescued_data IS NOT NULL and _rescued_data <> '{}') or _corrupt_record is NOT NULL")
            .selectExpr("*", "replace(_corrupt_record,'\"','\\'') as _corrupt_record")
            .drop(F.col("in._corrupt_record"))
        )
dfInvalidKO1.show()

dfValidKO2 = dfKO2.where("(_rescued_data IS NULL or _rescued_data = '{}') and _corrupt_record is NULL").drop("_rescued_data", "_corrupt_record")
dfValidKO2.show()
dfInvalidKO2 = (
            dfKO2.alias("in")
            .where("(_rescued_data IS NOT NULL and _rescued_data <> '{}') or _corrupt_record is NOT NULL")
            .selectExpr("*", "replace(_corrupt_record,'\"','\\'') as _corrupt_record")
            .drop(F.col("in._corrupt_record"))
        )
dfInvalidKO2.show()
