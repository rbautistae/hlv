# Databricks notebook source
# MAGIC %md
# MAGIC ### 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dynamic source schema&data creation

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
import random


def generate_sample_data(schema):
    """
    Generate sample data based on the schema.

    Parameters
    ----------
    schema : StructType
        The schema of the table.

    Returns
    -------
    list of tuples
        Sample data that matches the schema.
    """
    sample_data = []
    for i in range(5):  # Generate 5 rows
        row = []
        for field in schema.fields:
            if field.dataType == IntegerType():
                row.append(random.randint(1, 100))  # Random integer
            elif field.dataType == StringType():
                row.append(f"Sample_{random.randint(1, 100)}")  # Random string
            elif field.dataType == FloatType():
                row.append(round(random.uniform(1000.0, 5000.0), 2))  # Random float
            else:
                row.append(None)  # Handle unsupported types or null values
        sample_data.append(tuple(row))
    return sample_data

def create_table_with_schema(table_name, schema):
    """
    Creates or overwrites a table in Databricks with schema

    Parameters
    ----------
    table_name : str
        The name of the Databricks table to create or overwrite.
    schema : StructType
        The schema to apply to the table.

    Returns
    -------
    None
    """
    # Create an empty DataFrame with the provided schema
    empty_df = spark.createDataFrame([], schema)

    # Write the DataFrame to create or overwrite the table
    empty_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(table_name)

    print(f"Table '{table_name}' created or overwritten with the schema:{schema}")
    
    #  Insert 10 rows into the table dynamically
    data = generate_sample_data(schema)  # xxx Generate sample data
    sample_df = spark.createDataFrame(data, schema)  # xxx Create a DataFrame with the sample data
    sample_df.write.format("delta").mode("append").saveAsTable(table_name)  # xxx Append the data to the table
    print(f"10 rows inserted into the table '{table_name}'.")


def generate_dynamic_schema():
    """
    Generates a random dynamic schema for demonstration purposes.

    Returns
    -------
    StructType
        A randomly generated schema.
    """
    # Define some potential fields with randomization
    fields = [
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        # StructField("age", IntegerType(), random.choice([True, False])),
        # StructField("salary", FloatType(), random.choice([True, False])),
        StructField("age", IntegerType(), True),
        StructField("salary", FloatType(), True),
        StructField("department", StringType(), True),
    ]
    
    # Randomly shuffle and select a subset of fields
    random.shuffle(fields)
    selected_fields = random.sample(fields, random.randint(2, len(fields)))

    return StructType(selected_fields)



# COMMAND ----------

srcTableName = "dham_dwa_explorer_devl.raul_bautista.uc_source"
dstTableName = "dham_dwa_explorer_devl.raul_bautista.uc_destination"

# Generate a new src schema for testing
schema = generate_dynamic_schema()

# Create or overwrite the table with the dynamic schema
create_table_with_schema(srcTableName, schema)


# COMMAND ----------

# %sql 
# --drop table if exists dham_dwa_explorer_devl.raul_bautista.uc_source;
# --drop table if exists dham_dwa_explorer_devl.raul_bautista.uc_destination;


# COMMAND ----------

